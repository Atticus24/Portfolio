from flask import Flask, request, jsonify
import mysql.connector
from flask_bcrypt import Bcrypt
import pyotp
from datetime import datetime
from db_credentials import credentials

# from decouple import config

app = Flask(__name__)
bcrypt = Bcrypt(app)

def create_app():
    app = Flask(__name__)
    bcrypt = Bcrypt(app)

    @app.route("/login_otp", methods=["POST"])
    def login_otp():
        data = request.json
        email = data["email"]
        otp_candidate = data["otp"]

        result = logintodb_otp(email, otp_candidate)
        return jsonify(result)

    def logintodb_otp(
            email, otp_candidate
    ):  # parametrizes login credentials for input sanitation
        cursor = None
        db = None  # Initialize db outside the try-except block
        try:  # where in the function should database connection occur? Write about it in documentation
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )
            cursor = db.cursor()

            # Now retrieving user_type as well
            query = "SELECT user_type, secret_key FROM users WHERE email = %s"
            cursor.execute(query, (email,))  # expects tuple, comma is thus needed.
            user = cursor.fetchone()

            if user:
                user_type, secret_key = user
                totp = pyotp.TOTP(secret_key)
                if totp.verify(otp_candidate):
                    return {
                        "success": True,
                        "message": "Login successful",
                        "user_type": user_type,
                    }
                else:
                    return {"success": False, "message": "Incorrect OTP"}
            else:
                return {"success": False, "message": "Invalid email"}
        except mysql.connector.Error as e:
            return {"success": False, "message": f"Database error: {e}"}
        except Exception as e:
            return {"success": False, "message": f"Unhandled exception: {str(e)}"}
        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    @app.route("/login_password", methods=["POST"])
    def login_pw():
        data = request.json
        email = data["email"]
        password_candidate = data["password"]
        result = logintodb_pw(email, password_candidate)
        return jsonify(result)

    def logintodb_pw(
            email, password_candidate
    ):  # parametrizes login credentials for input sanitation
        cursor = None
        db = None  # Initialize db outside the try-except block

        try:  # where in the function should database connection occur? Write about it in documentation
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )
            cursor = db.cursor()

            query = "SELECT user_type, backup_password FROM users WHERE email = %s"
            cursor.execute(query, (email,))  # expects tuple, comma is thus needed.
            user = cursor.fetchone()

            if user:
                user_type, pw_hash = user
                if bcrypt.check_password_hash(pw_hash, password_candidate):
                    return {
                        "success": True,
                        "message": "Correct password!",
                        "user_type": user_type,
                    }
                else:
                    return {"success": False, "message": "Incorrect password"}
            else:
                return {"success": False, "message": "Invalid email"}
        except mysql.connector.Error as e:
            return {"success": False, "message": f"Database error: {e}"}
        except Exception as e:
            return {"success": False, "message": f"Unhandled exception: {str(e)}"}
        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    @app.route("/register_user", methods=["POST"])
    def register():
        data = request.json
        email = data.get("email")
        firstname = data.get("firstname")
        lastname = data.get("lastname")
        user_type = data.get(
            "user_type", "Admin"
        )  # Default to "Student" if user_type is missing
        backup_password = data.get("backup_password")

        if not email:
            return jsonify({"success": False, "message": "Email is required"}), 400

        result = register_user(email, firstname, lastname, user_type, backup_password)
        return jsonify(result)

    def register_user(email, firstname, lastname, user_type, backup_password):
        cursor = None
        db = None  # Initialize db outside the try-except block

        try:
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )

            cursor = db.cursor()
            search_query = "SELECT email FROM users WHERE email = %s"
            cursor.execute(search_query, (email,))
            existing_user = cursor.fetchone()

            if existing_user:
                return {"success": False, "message": "Email already exists"}

            # Insert new user
            secret_key, qr_url = generate_secret_key_and_qr_url(email)
            pw_hash = bcrypt.generate_password_hash(backup_password)
            insert_query = "INSERT INTO users (email, firstname, lastname, user_type, backup_password, secret_key) VALUES (%s, %s, %s, %s, %s, %s)"
            cursor.execute(
                insert_query, (email, firstname, lastname, user_type, pw_hash, secret_key)
            )
            db.commit()
            return {
                "success": True,
                "message": "User registered successfully",
                "qr_url": qr_url,
            }

        except mysql.connector.Error as e:
            return {"success": False, "message": f"Database error: {e}"}
        except Exception as e:
            return {"success": False, "message": f"Unhandled exception: {str(e)}"}
        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    def generate_secret_key_and_qr_url(email):
        secret_key = pyotp.random_base32()
        qr_url = pyotp.TOTP(secret_key).provisioning_uri(
            name=email, issuer_name="C.R.A.F.T"
        )
        return secret_key, qr_url

    @app.route("/change_user_type", methods=["POST"])
    def change_user_type():
        data = request.json
        email = data.get("email")
        user_type = data.get("user_type")

        if not email:
            return jsonify({"success": False, "message": "Email is required"}), 400

        result = update_user_type_db(email, user_type)
        return jsonify(result)

    def update_user_type_db(email, user_type):
        cursor = None
        db = None  # Initialize db outside the try-except block

        try:
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )
            cursor = db.cursor()

            search_query = "SELECT user_type FROM `users` WHERE email = %s"
            cursor.execute(search_query, (email,))
            existing_user_type = cursor.fetchone()

            if existing_user_type is None:
                return {"success": False, "message": "Could not find user"}

            if existing_user_type[0] != user_type:
                update_query = "UPDATE `users` SET user_type = %s WHERE email = %s"
                cursor.execute(update_query, (user_type, email))
                db.commit()
                return {"success": True, "message": "User type has been updated"}

            if existing_user_type[0] == user_type:
                return {"success": False, "message": "User already has this type"}

        except mysql.connector.Error as e:
            return {"success": False, "message": f"Database error: {e}"}

        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    @app.route("/fetch_all_users", methods=["GET"])
    def fetch_all_users():
        cursor = None
        db = None  # Initialize db outside the try-except block

        try:
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )
            cursor = db.cursor()

            query = "SELECT email, firstname, lastname, user_type FROM `users` ORDER BY firstname, lastname ASC"
            cursor.execute(
                query,
            )
            groups = [
                {
                    "email": row[0],
                    "firstname": row[1],
                    "lastname": row[2],
                    "user_type": row[3],
                }
                for row in cursor.fetchall()
            ]
            return jsonify(groups)

        except mysql.connector.Error as e:
            return {"success": False, "message": f"Database error: {e}"}

        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    @app.route("/delete_user", methods=["POST"])
    def collect_email():
        data = request.json
        email = data["email"]
        result = delete_user_from_db(email)
        return jsonify(result)

    def delete_user_from_db(email):  # parametrizes login credentials for input sanitation
        cursor = None
        db = None  # Initialize db outside the try-except block
        try:  # where in the function should database connection occur? Write about it in documentation
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )
            cursor = db.cursor()

            # safeguard - check that user exists
            query = "SELECT * FROM users WHERE email = %s"
            cursor.execute(query, (email,))  # expects tuple, comma is thus needed.
            user = cursor.fetchone()

            if user:
                delete_query = "DELETE FROM users WHERE email = %s"
                cursor.execute(
                    delete_query, (email,)
                )  # expects tuple, comma is thus needed.
                deleted_user = cursor.fetchone()
                db.commit()  # confirm deletion

                if deleted_user is None:
                    return {
                        "success": True,
                        "message": "User has been deleted successfully",
                        "email": email,
                    }
                else:
                    return {"success": False, "message": "Failed to delete user"}
            else:
                return {"success": False, "message": "Could not find user"}

        except mysql.connector.Error as e:
            return {"success": False, "message": f"Database error: {e}"}

        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    # SENSOR MODULES
    @app.route("/fetch_sensors", methods=["GET"])
    def fetch_sensor_info():
        try:
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )
            cursor = db.cursor()
            query = "SELECT id, name, type, producer FROM sensors ORDER BY id ASC"
            cursor.execute(query)
            sensors = [
                {"id": row[0], "name": row[1], "type": row[2], "producer": row[3]}
                for row in cursor.fetchall()
            ]
            return jsonify(sensors)
        except mysql.connector.Error as e:
            return {"success": False, "message": f"Database error: {e}"}
        finally:

            if cursor:
                cursor.close()
            if db:
                db.close()

    @app.route("/add_sensor", methods=["POST"])
    def add_sensor():
        data = request.json
        name = data.get("name")
        type = data.get("type")
        producer = data.get("producer")

        if not name or not type or not producer:
            return jsonify({"success": False, "message": "All fields must be filled"}), 400

        result = add_sensor_to_db(name, type, producer)
        return jsonify(result)

    def add_sensor_to_db(name, type, producer):
        cursor = None
        db = None  # Initialize db outside the try-except block

        try:
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )

            cursor = db.cursor()

            insert_query = "INSERT INTO sensors (name, type, producer) VALUES (%s, %s, %s)"
            new_sensor = cursor.execute(insert_query, (name, type, producer))
            print(new_sensor)
            db.commit()
            return {"success": True, "message": "Sensor registered successfully"}

        except mysql.connector.Error as e:
            return {"success": False, "message": f"Database error: {e}"}
        except Exception as e:
            return {"success": False, "message": f"Unhandled exception: {str(e)}"}
        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    @app.route("/delete_sensor", methods=["POST"])
    def delete_sensor():

        data = request.json
        id = data["id"]
        result = delete_sensor_from_db(id)
        return jsonify(result)

    def delete_sensor_from_db(sensor_id):
        db = None
        cursor = None
        try:
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )
            cursor = db.cursor()

            # Delete associated sub-sensors first
            cursor.execute("DELETE FROM sub_sensors WHERE module_id = %s", (sensor_id,))
            db.commit()

            # Then delete the sensor
            cursor.execute("DELETE FROM sensors WHERE id = %s", (sensor_id,))
            db.commit()

            if cursor.rowcount > 0:
                return {"success": True, "message": "Sensor deleted successfully"}
            else:
                return {"success": False, "message": "No sensor found with that ID"}
        except mysql.connector.Error as e:
            return {"success": False, "message": str(e)}
        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    # SUB SENSORS
    @app.route("/fetch_sub_sensors", methods=["GET"])
    def fetch_sub_sensors():
        sensor_id = request.args.get("sensor_id")  # We're using sensor_id now
        if not sensor_id:
            return {"success": False, "message": "Missing sensor ID parameter."}

        try:
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )

            cursor = db.cursor()
            query = "SELECT id, type, measuring_unit, alt_measuring_unit FROM sub_sensors WHERE module_id = %s ORDER BY id ASC"
            cursor.execute(query, (sensor_id,))
            sub_sensors = cursor.fetchall()
            return jsonify(
                [
                    {
                        "id": sub_sensor[0],
                        "type": sub_sensor[1],
                        "measuring_unit": sub_sensor[2],
                        "alt_measuring_unit": sub_sensor[3],
                    }
                    for sub_sensor in sub_sensors
                ]
            )

        except mysql.connector.Error as e:
            return {"success": False, "message": f"Database error: {e}"}
        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    @app.route("/add_sub_sensor", methods=["POST"])
    def add_sub_sensor():
        data = request.json

        name = data.get("name")
        module_id = data.get("module_id")
        measuring_unit = data.get("measuring_unit")
        alt_measuring_unit = data.get("alt_measuring_unit")

        print(name, measuring_unit)

        if not name or not module_id:
            return (
                jsonify({"success": False, "message": "Fill in all obligatory fields"}),
                400,
            )

        result = add_sub_sensor_to_db(name, module_id, measuring_unit, alt_measuring_unit)
        return jsonify(result)

    def add_sub_sensor_to_db(name, module_id, measuring_unit, alt_measuring_unit):
        cursor = None
        db = None  # Initialize db outside the try-except block

        try:
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )
            cursor = db.cursor()

            # check if sensor module exists
            search_query = "SELECT id FROM sensors WHERE id = %s"
            cursor.execute(search_query, (module_id,))
            existing_module = cursor.fetchone()

            if not existing_module:
                return {"success": False, "message": "No sensor module with that ID exists"}

            if existing_module:
                insert_query = "INSERT INTO sub_sensors (`type`, module_id, measuring_unit, alt_measuring_unit) VALUES (%s, %s, %s, %s)"
                new_sub_sensor = cursor.execute(insert_query, (name, module_id, measuring_unit, alt_measuring_unit))
                print(new_sub_sensor)

            db.commit()
            return {"success": True, "message": "Sub sensor registered successfully"}

        except mysql.connector.Error as e:
            return {"success": False, "message": f"Database error: {e}"}
        except Exception as e:
            return {"success": False, "message": f"Unhandled exception: {str(e)}"}
        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    @app.route("/delete_sub_sensor", methods=["POST"])
    def delete_sub_sensor():
        data = request.json
        id = data["id"]
        result = delete_sub_sensor_from_db(id)
        return jsonify(result)

    def delete_sub_sensor_from_db(
            id,
    ):  # parametrizes login credentials for input sanitation
        cursor = None
        db = None  # Initialize db outside the try-except block
        try:  # where in the function should database connection occur? Write about it in documentation
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )
            cursor = db.cursor()

            # safeguard - check that user exists
            query = "SELECT * FROM sub_sensors WHERE id = %s"
            cursor.execute(query, (id,))  # expects tuple, comma is thus needed.
            sub_sensor = cursor.fetchone()

            if sub_sensor:
                delete_query = "DELETE FROM sub_sensors WHERE id = %s"
                cursor.execute(delete_query, (id,))  # expects tuple, comma is thus needed.
                deleted_user = cursor.fetchone()
                db.commit()  # confirm deletion

                if deleted_user is None:
                    return {
                        "success": True,
                        "message": "Sub sensor has been deleted successfully",
                        "sub_sensor": sub_sensor,
                    }
                else:
                    return {"success": False, "message": "Failed to delete sub sensor"}
            else:
                return {"success": False, "message": "Could not find sub sensor"}

        except mysql.connector.Error as e:
            return {"success": False, "message": f"Database error: {e}"}

        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    # COURSES
    @app.route("/fetch_courses", methods=["GET"])
    def fetch_courses():
        try:
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )
            cursor = db.cursor()

            query = "SELECT * FROM courses ORDER BY id"
            cursor.execute(query)
            courses = [
                {"id": row[0], "start_date": row[1], "end_date": row[2]}
                for row in cursor.fetchall()
            ]
            return jsonify(courses)

        except mysql.connector.Error as e:
            return {"success": False, "message": f"Database error: {e}"}

        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    @app.route("/fetch_course_ids", methods=["GET"])
    def fetch_course_ids():
        try:
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )
            cursor = db.cursor()

            query = "SELECT id FROM courses ORDER BY id"
            cursor.execute(query)
            courses = [{"id": row[0]} for row in cursor.fetchall()]
            return jsonify(courses)

        except mysql.connector.Error as e:
            return {"success": False, "message": f"Database error: {e}"}

        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    @app.route("/register_course", methods=["POST"])
    def register_course():
        data = request.json
        start_date = data.get("start")
        end_date = data.get("end")

        if not start_date or not end_date:
            return jsonify({"success": False, "message": "Missing start or end date"}), 400

        result = register_course_to_db(start_date, end_date)
        return jsonify(result)

    def register_course_to_db(start_date, end_date):
        try:
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )
            cursor = db.cursor()

            # Insert the new course into the database
            insert_query = "INSERT INTO courses (start_date, end_date) VALUES (%s, %s)"
            cursor.execute(insert_query, (start_date, end_date))
            db.commit()
            return {"success": True, "message": "Course registered successfully"}

        except mysql.connector.Error as e:
            return {"success": False, "message": f"Database error: {e}"}

        finally:
            cursor.close()
            db.close()

    # GROUPS
    @app.route("/register_group", methods=["POST"])
    def register_group():
        data = request.json
        group_name = data.get("group_name")
        if not group_name:
            return jsonify({"success": False, "message": "Group name is required"}), 400

        result = insert_group(group_name)
        return jsonify(result)

    def insert_group(group_name):
        cursor = None
        db = None  # Initialize db outside the try-except block

        try:
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )
            cursor = db.cursor()

            # Check if group already exists
            search_query = "SELECT name FROM `groups` WHERE name = %s"
            cursor.execute(search_query, (group_name,))
            existing_group = cursor.fetchone()

            if existing_group:
                return {"success": False, "message": "Group name already exists"}

            # Insert new group
            insert_query = "INSERT INTO `groups` (name, creation_date) VALUES (%s, %s)"
            creation_date = datetime.now().strftime(
                "%Y-%m-%d %H:%M:%S"
            )  # Current date and time
            cursor.execute(insert_query, (group_name, creation_date))
            db.commit()
            return {"success": True, "message": "Group registered successfully"}

        except mysql.connector.Error as e:
            return {"success": False, "message": f"Database error: {e}"}
        except Exception as e:
            return {"success": False, "message": f"Unhandled exception: {str(e)}"}
        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    @app.route("/fetch_attached_groups/<int:course_id>", methods=["GET"])
    def fetch_attached_groups(course_id):
        try:
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )
            cursor = db.cursor()

            query = "SELECT id, name, size FROM `groups` WHERE course_id = %s ORDER BY id"
            cursor.execute(query, (course_id,))
            groups = [
                {"id": row[0], "name": row[1], "size": row[2]} for row in cursor.fetchall()
            ]
            return jsonify(groups)

        except mysql.connector.Error as e:
            return {"success": False, "message": f"Database error: {e}"}

        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    @app.route("/add_user_to_group", methods=["POST"])
    def add_user_to_group():
        data = request.json
        user_id = data.get("username")
        group_id = data.get("group_id")

        if not user_id or not group_id:
            return (
                jsonify({"success": False, "message": "User ID and Group ID are required"}),
                400,
            )

        result = update_user_group(user_id, group_id)
        print(result)
        return jsonify(result)

    def update_user_group(user_id, group_id):
        cursor = None
        db = None
        try:
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )
            cursor = db.cursor()

            # Check if the group exists
            group_query = "SELECT id FROM `groups` WHERE id = %s"
            cursor.execute(group_query, (group_id,))
            group_exists = cursor.fetchone()

            # Check if the user exists
            user_query = "SELECT email FROM users WHERE email = %s"
            cursor.execute(user_query, (user_id,))
            user_exists = cursor.fetchone()

            if not group_exists or not user_exists:
                return {"success": False, "message": "Group and/or user does not exist"}

            print("inserting...")

            # Update or insert into user_group
            update_query = "INSERT INTO usergroups (user_id, group_id) VALUES (%s, %s) ON DUPLICATE KEY UPDATE group_id = VALUES(group_id)"
            cursor.execute(update_query, (user_id, group_id))
            db.commit()
            return {"success": True, "message": "User added to group successfully"}

        except mysql.connector.Error as e:
            return {"success": False, "message": f"Database error: {e}"}
        except Exception as e:
            return {"success": False, "message": f"Unhandled exception: {str(e)}"}
        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    @app.route("/fetch_all_groups", methods=["GET"])
    def fetch_all_groups():
        try:
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )
            cursor = db.cursor()

            query = (
                "SELECT id, name, size, creation_date, course_id FROM `groups` ORDER BY id"
            )
            cursor.execute(
                query,
            )
            groups = [
                {
                    "id": row[0],
                    "name": row[1],
                    "size": row[2],
                    "creation_date": row[3],
                    "course_id": row[4],
                }
                for row in cursor.fetchall()
            ]
            return jsonify(groups)

        except mysql.connector.Error as e:
            return {"success": False, "message": f"Database error: {e}"}

        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    @app.route("/fetch_group_members/<int:group_id>", methods=["GET"])
    def fetch_group_members(group_id):
        try:
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )
            cursor = db.cursor()

            query = """
            SELECT u.email, u.firstname, u.lastname
            FROM users u
            INNER JOIN usergroups ug ON u.email = ug.user_id
            WHERE ug.group_id = %s
            """
            cursor.execute(query, (group_id,))
            members = [
                {"email": row[0], "firstname": row[1], "lastname": row[2]}
                for row in cursor.fetchall()
            ]
            return jsonify(members)

        except mysql.connector.Error as e:
            return {"success": False, "message": f"Database error: {e}"}, 500

        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    @app.route("/fetch_group_ids_and_names", methods=["GET"])
    def fetch_group_ids_and_names():
        try:
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )
            cursor = db.cursor()

            query = "SELECT id, name ORDER BY id"
            cursor.execute(
                query,
            )
            groups = [{"id": row[0], "name": row[1]} for row in cursor.fetchall()]
            return jsonify(groups)

        except mysql.connector.Error as e:
            return {"success": False, "message": f"Database error: {e}"}

        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    @app.route("/delete_group", methods=["POST"])
    def delete_group():
        data = request.json
        group_id = data["id"]
        result = delete_group_from_db(group_id)
        return jsonify(result)

    def delete_group_from_db(group_id):
        db = None
        cursor = None
        try:
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )
            cursor = db.cursor()
            cursor.execute("DELETE FROM `groups` WHERE id = %s", (group_id,))
            db.commit()
            return {
                "success": True,
                "message": "Group and associated satellites deleted successfully",
            }
        except mysql.connector.Error as e:
            return {"success": False, "message": str(e)}
        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    # SATELLITES
    @app.route("/add_satellite", methods=["POST"])
    def add_satellite():
        data = request.json
        name = data.get("name")
        sat_type = data.get("sat_type")
        group_id = data.get("group_id")

        if not name or not type or not group_id:
            return jsonify({"success": False, "message": "All fields must be filled"}), 400

        result = add_satellite_to_db(name, sat_type, group_id)
        return jsonify(result)

    def add_satellite_to_db(name, sat_type, group_id):
        cursor = None
        db = None  # Initialize db outside the try-except block

        try:
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )
            cursor = db.cursor()

            search_query = "SELECT id FROM `groups` WHERE id = %s"
            cursor.execute(search_query, (group_id,))
            existing_group = cursor.fetchone()

            if not existing_group:
                return {"success": False, "message": "No group with that ID exists"}

            print("inserting into database")
            print(name, type, group_id)
            insert_query = (
                "INSERT INTO satellites (name, `type`, group_id) VALUES (%s, %s, %s)"
            )
            cursor.execute(insert_query, (name, sat_type, group_id))
            db.commit()
            return {"success": True, "message": "Satellite registered successfully"}

        except mysql.connector.Error as e:
            return {"success": False, "message": f"Database error: {e}"}
        except Exception as e:
            return {"success": False, "message": f"Unhandled exception: {str(e)}"}
        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    @app.route("/fetch_all_satellites", methods=["GET"])
    def fetch_all_satellites():
        try:
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )
            cursor = db.cursor()

            query = "SELECT name, type, group_id FROM `satellites` ORDER BY name ASC"
            cursor.execute(
                query,
            )
            satellites = [
                {"name": row[0], "type": row[1], "group_id": row[2]}
                for row in cursor.fetchall()
            ]
            return jsonify(satellites)

        except mysql.connector.Error as e:
            return {"success": False, "message": f"Database error: {e}"}, 500

        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    @app.route("/delete_satellite", methods=["POST"])
    def delete_satellite():
        data = request.json
        sat_name = data["sat_name"]
        result = delete_satellite_from_db(sat_name)
        return jsonify(result)

    def delete_satellite_from_db(sat_name):
        db = None
        cursor = None
        try:
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )
            cursor = db.cursor()
            cursor.execute("DELETE FROM satellites WHERE name = %s", (sat_name,))
            db.commit()

            return {"success": True, "message": "Satellite deleted successfully"}
        except mysql.connector.Error as e:
            return {"success": False, "message": str(e)}
        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    # Daniel
    @app.route("/fetch_group_name/<string:user_email>", methods=["GET"])
    def fetch_group_name(user_email):
        db = None
        cursor = None
        try:
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )
            cursor = db.cursor()

            query = """
            SELECT g.name 
            FROM usergroups ug 
            INNER JOIN `groups` g ON g.id = ug.group_id
            WHERE ug.user_id = %s
            """

            cursor.execute(query, (user_email,))

            rows = cursor.fetchall()

            if rows:
                group_name = rows[0][0]  # Get the first result ('name' from 'groups' table)
                return group_name
            else:
                return 'No group found for this user email', 404

        except mysql.connector.Error as e:
            return {"success": False, "message": f"Database error: {e}"}, 500

        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    @app.route("/fetch_all_group_names", methods=["GET"])
    def fetch_all_group_names():
        db = None
        cursor = None
        try:
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )
            cursor = db.cursor()

            query = "SELECT name FROM `groups`"

            cursor.execute(query)

            rows = cursor.fetchall()

            if rows:
                group_names = [row[0] for row in rows]  # Get all group names
                return {"success": True, "group_names": group_names}
            else:
                return 'No groups found', 404

        except mysql.connector.Error as e:
            return {"success": False, "message": f"Database error: {e}"}, 500

        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    @app.route("/fetch_all_sub_sensors", methods=["GET"])
    def fetch_all_sub_sensor_names():
        db = None
        cursor = None
        try:
            db = mysql.connector.connect(
                host=credentials["host"],
                user=credentials["user"],
                password=credentials["password"],
                database=credentials["database"],
            )
            cursor = db.cursor()
            query = "SELECT id, type, measuring_unit, alt_measuring_unit, module_id FROM sub_sensors ORDER BY type ASC"
            cursor.execute(query)
            sub_sensors = [
                {
                    "id": row[0],
                    "type": row[1],
                    "measuring_unit": row[2],
                    "alt_measuring_unit": row[3],
                    "module_id": row[4],
                }
                for row in cursor.fetchall()
            ]
            return jsonify(sub_sensors)
        except mysql.connector.Error as e:
            return {"success": False, "message": f"Database error: {e}"}
        finally:
            if cursor:
                cursor.close()
            if db:
                db.close()

    return app