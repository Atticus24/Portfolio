import tkinter as tk
from tkinter import ttk
from tkintermapview import TkinterMapView

import matplotlib
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import matplotlib.dates as mdates
import numpy as np
#import ttkbootstrap as ttk
import random
import time
#from ttkbootstrap import Style
import csv
import pandas as pd
import os
import datetime
import serial
import threading
import queue
import re

#import googlemaps
#import config
#from PIL import ImageTk, Image
#import requests
#from io import BytesIO
#from tkinterweb import HtmlFrame

#from Thread.plotmodule_thread import ser

#ser = serial.Serial("COM3", 9600) # this is an example, use your port and baud rate

matplotlib.use("TkAgg")

class GraphPlot(tk.Frame):
    def __init__(self, parent, main_obj, plot_id, title, line_color, x_label, y_label, *args, **kwargs):

        tk.Frame.__init__(self, parent, *args, **kwargs)
        self.main_obj = main_obj
        self.start_time = datetime.datetime.now()
        self.elapsed_time = 0
        self.data_points = []
        self.x_val = 0.0
        self.last_x = None
        self.cumulative_x = 0


        self.plot_id = plot_id
        self.title = title
        self.title_nr = f"{plot_id}_{title}"
        self.x_label = x_label  # Add this line of code
        self.y_label = y_label  # Add this line also
        self.x_update_val = 1
        self.line_color = line_color
        self.queue = queue.Queue()  # Each plot gets its unique queue
        self.lock = threading.Lock()

        self.fig = Figure(figsize=(6, 4), dpi=50) # Changed dpi from 100
        self.configure_matplotlib_settings()

        self.plot = self.fig.add_subplot(111)
        self.configure_matplotlib_settings()
        self.fig.patch.set_facecolor("darkgrey")
        self.canvas = FigureCanvasTkAgg(self.fig, master=self)
        self.canvas.draw()

        # Use grid instead of pack and make it expand in all directions
        self.canvas.get_tk_widget().grid(row=0, column=0, sticky="nsew")
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        self.line, = self.plot.plot([], [], marker="", linewidth=1.5, color=self.line_color, label=self.title)  # initial empty line
        self.update_plot()

        self.temp_folder = "temp_files"

        self.data = None  # initializes to None to make sure DataFrame is created on the first data read
        self.save_time = None

        style = ttk.Style()
        # create red button style
        style.configure("TButton",
                        background='red',
                        foreground='white',
                        font=('arial', 8, 'bold'),
                        relief='raised')

        # Add the exit button as a child to the plot frame:
        exit_button = ttk.Button(self, text="X", command=self.close, style="TButton")
        exit_button.place(relx=1, rely=0, width=27, height=27, anchor='ne')

    def add_datapoint(self, data_row):
        if self.y_label in data_row and self.x_label in data_row:
            y_val = data_row[self.y_label]
            packet_counter = data_row.get("packet_counter", None)  # This line sets "packet_counter" value
            if self.x_label in data_row:
                if self.x_label == "Date Time":
                    self.save_time = data_row[self.x_label]
                    current_x = data_row[self.x_label]
                else:
                    current_x = data_row[self.x_label]


                # If this is the first datapoint, add it directly.
                if self.last_x is None:
                    self.queue.put((current_x, y_val, packet_counter))  # Adding "packet_counter" value
                    self.cumulative_x = current_x
                else:
                    if self.x_label == "Date Time":
                        self.queue.put((current_x, y_val, packet_counter))  # Adding "packet_counter" value
                        return

                    # Increment cumulative value
                    self.cumulative_x += abs(current_x - self.last_x)

                    # Add the cumulative value to the plot"s queue
                    self.queue.put((self.cumulative_x, y_val, packet_counter))  # Also here

                # Now, set "last_x" to current x
                self.last_x = current_x

    def configure_matplotlib_settings(self):
        matplotlib.rcParams["axes.facecolor"] = "darkgrey"
        matplotlib.rcParams["xtick.labelsize"] = 16
        matplotlib.rcParams["ytick.labelsize"] = 16
        matplotlib.rcParams["axes.titlesize"] = 16
        matplotlib.rcParams["legend.fontsize"] = 12
        matplotlib.rcParams["xtick.direction"] = "in"
        matplotlib.rcParams["ytick.direction"] = "in"

    def sanitize_filename(self, name, replacement="_"):
        """
        Sanitize the filename by replacing all invalid characters.
        :param name: Original filename
        :param replacement: Character to replace invalid filename characters to
        :return: Sanitized filename
        """
        # Define a list of invalid characters. You may need to modify this for OS compatibility
        invalid_chars = r'[\/:*?"<>|]'
        return re.sub(invalid_chars, replacement, name)

    def update_plot(self):
        while not self.queue.empty():
            self.data_points.append(self.queue.get())  # Add data point to list

            if len(self.data_points) > 20:
                self.data_points.pop(0)  # Remove first item if length of data_points exceeds 20

            self.refresh_plot()
            elapsed_seconds = round((datetime.datetime.now() - self.start_time).total_seconds())
            self.elapsed_time = str(datetime.timedelta(seconds=elapsed_seconds))

            safe_title = self.sanitize_filename(self.title_nr)
            self.write_to_csv(os.path.join(self.temp_folder, f"{safe_title}.csv"))

        self.after(200, self.update_plot)
    def update_line(self, xdata, ydata):
        self.line.set_xdata(xdata)
        self.line.set_ydata(ydata)
        self.fig.tight_layout(pad=0.5)
        self.plot.tick_params(axis="both", which="major", labelsize= 12)
        self.canvas.draw()

    # Refresh plot
    def refresh_plot(self):
        if self.data_points:
            # If data is available, unpack it into x_vals and y_vals
            x_vals, y_vals, packet_counter = zip(*self.data_points[-10:])
        else:
            # If no data is available, create empty lists for x_vals and y_vals
            x_vals, y_vals, packet_counter = [], [], []

        self.plot_clear_and_configure(x_vals, y_vals)
        self.update_line(x_vals, y_vals)  # Call the function to set data for the line plot

    def plot_clear_and_configure(self, x_vals, y_vals):
        if x_vals and y_vals:  # check if x_vals and y_vals are not empty
            self.line.set_label(f"{self.y_label}: {y_vals[-1]:.4f}")
            self.plot.set_xlabel(self.x_label, fontsize=14)
            self.plot.set_ylabel(self.y_label, fontsize=14)
            self.plot.set_facecolor("white")
            self.plot.grid(True, which="both", color=self.line_color, alpha=0.5, linewidth=0.3)

            if self.x_label == "Date Time":
                self.plot.xaxis_date()  # This line is important for dealing with dates on x-axis
                min_x, max_x = mdates.date2num(min(x_vals)), mdates.date2num(
                    max(x_vals))  # Convert dates into numbers matplotlib can understand
                if min_x != max_x:
                 self.plot.set_xlim([min_x, max_x])
                else:
                 self.plot.set_xlim([min_x - 0.001, max_x + 0.001])

                self.plot.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M:%S"))  # Format x-axis data as time

            else:
                min_x, max_x = min(x_vals), max(x_vals)
                if min_x != max_x:
                    self.plot.set_xlim([min_x, max_x])
                else:
                    self.plot.set_xlim([min_x - 0.001, max_x + 0.001])

            min_y, max_y = min(y_vals), max(y_vals)
            y_diff = max_y - min_y
            self.plot.set_ylim([min_y - (0.1 * y_diff), max_y + (0.1 * y_diff)])  # 10% padding

            self.plot.legend(loc="upper right")
            self.fig.autofmt_xdate()  # rotate and align the tick labels


    def reset_df(self):
        self.data = None

    def write_to_csv(self, filename):
        with self.lock:

            if self.data_points:  # check if data_points is not empty

                # generated the row data and datetime once so they are the same
                x_val, y_val, packet_counter = self.data_points[-1]  # note: only the last datapoint

                if self.x_label == "Date Time":
                    x_val = self.save_time.strftime("%H:%M:%S")

                # prepare the data to be DataFrame. Replace "," to "." and set the precision as 4
                df_data = {f"{self.plot_id}X_{self.x_label}": x_val,
                           f"{self.plot_id}Y_{self.y_label}": y_val}

                # Convert the data_row to a DataFrame
                df = pd.DataFrame(df_data, index=[0])

                #print(df)

                if not df.empty:
                    # Check if DataFrame is None (i.e., this is the first row of data)
                    if self.data is None:
                        # If so, initialize DataFrame with variable names from data_row
                        self.data = df

                        # Add "formatted_date" at the beginning of the DataFrame
                        self.data.insert(0, f"{self.title_nr}", datetime.datetime.now().strftime("%Y.%m.%d"))
                        self.data[" "] = ""

                    else:
                        # Concatenating the new data row DataFrame with the existing DataFrame
                        self.data = pd.concat([self.data, df], ignore_index=True)

                    # Save data to temporary CSV file with separator as ;
                    temp_data = self.data.copy()
                    # temp_data.to_csv(temp_file_path, index=False, sep=";")
                    #temp_data = temp_data.apply(
                    #    lambda x: x.map(lambda v: str(v).replace(".", ",") if pd.notnull(v) else ""))
                    temp_data.to_csv(filename, index=False, sep=";")

    def close(self):
        # Find the corresponding plot_info for the current plot
        plot_info_to_remove = next((plot_info for plot_info in self.main_obj.plots if plot_info['plot'] == self), None)

        # If the corresponding plot_info is found, remove it
        if plot_info_to_remove is not None:
            self.main_obj.plots.remove(plot_info_to_remove)

            # Retrieve the coordinates of the removed plot
            min_i, max_i, min_j, max_j = plot_info_to_remove['coordinates']

            # Display the corresponding grid buttons in the main class
            for i in range(min_i, max_i + 1):
                for j in range(min_j, max_j + 1):
                    self.main_obj.cell_buttons[i][j].grid()

        self.destroy()  # destroys the frame that holds the plot and the exit button


class TablePlot(tk.Frame):
    def __init__(self, parent, main_obj, table_list, *args, **kwargs):
        tk.Frame.__init__(self, parent, *args, **kwargs)

        self.main_obj = main_obj
        self.table_list = table_list
        if "Date Time" not in table_list:
            table_list.insert(0, "Date Time")
        self.df = pd.DataFrame(columns=table_list)  # Initialize an empty DataFrame with required columns.
        self.queue = queue.Queue()  # Initialize a queue to store incoming data_rows.
        self.treeview = ttk.Treeview(self, columns=self.table_list, show="headings")

        for col in self.table_list:
            self.treeview.heading(col, text=col)
            self.treeview.column(col, width=50)  # Set each column's width to 100 pixels

        # Use grid instead of pack and make it fill the available space
        self.treeview.grid(row=0, column=0, sticky='nsew')
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)

        style = ttk.Style()
        # create red button style
        style.configure("TButton",
                        background='red',
                        foreground='white',
                        font=('arial', 8, 'bold'),
                        relief='raised')

        # Add the exit button as a child to the plot frame:
        exit_button = ttk.Button(self, text="X", command=self.close, style="TButton")
        exit_button.place(relx=1, rely=0, width=27, height=27, anchor='ne')

    def add_datapoint(self, data_row):
        data_subset = {}  # dictionary to store key-value pairs from data_row that match with table_list
        for key in self.table_list:
            if key in data_row:
                if key == "Date Time":  # if key is "Date Time", convert datetime to string
                    data_subset[key] = data_row[key].strftime("%H:%M:%S")
                else:
                    data_subset[key] = data_row[key]

        if data_subset:  # if data_subset is not empty
            self.queue.put(data_subset)  # Put the data_subset into the queue
        else:
            print("None of the keys in table_list were found in data_row.")
            print("Keys in data_row:", data_row.keys())

    def update_plot(self):
        while not self.queue.empty():
            data_row = self.queue.get()  # Get data_row from queue.
            new_data = pd.DataFrame(data_row, index=[0])
            self.df = pd.concat([self.df, new_data], ignore_index=True)
            self.redisplay_df_in_treeview()  # Redisplay the DataFrame.

        self.after(200, self.update_plot)  # Call this function again after 200ms for continuous updates.

    def redisplay_df_in_treeview(self):
        self.treeview.delete(*self.treeview.get_children())  # Clear the Treeview.

        for index, row in self.df.iterrows():
            item_id = self.treeview.insert('', 'end', values=tuple(row))

        # Scroll the treeview to see the last inserted item
        self.treeview.see(item_id)

    def reset_df(self):
        return

    def close(self):
        # Find the corresponding plot_info for the current plot
        plot_info_to_remove = next((plot_info for plot_info in self.main_obj.plots if plot_info['plot'] == self), None)

        # If the corresponding plot_info is found, remove it
        if plot_info_to_remove is not None:
            self.main_obj.plots.remove(plot_info_to_remove)

            # Retrieve the coordinates of the removed plot
            min_i, max_i, min_j, max_j = plot_info_to_remove['coordinates']

            # Display the corresponding grid buttons in the main class
            for i in range(min_i, max_i + 1):
                for j in range(min_j, max_j + 1):
                    self.main_obj.cell_buttons[i][j].grid()

        self.destroy()  # destroys the frame that holds the plot and the exit button


class GpsPlot(tk.Frame):
    def __init__(self, parent, main_obj, lat_label, lng_label, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)
        self.main_obj = main_obj
        self.lat_label = lat_label
        self.lng_label = lng_label
        self.queue = queue.Queue()
        self.coordinates_list = []  # List for storing coordinates
        self.update_counter = 5  # Count the number of updates

        # Create a TkinterMapView widget
        self.map_frame = TkinterMapView(self)
        self.map_frame.set_zoom(12)
        self.map_frame.grid(row=0, column=0, sticky='nsew')

        # Keep a reference to the path object
        self.path = None

        # Configure grid to expand
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)

        style = ttk.Style()
        # create red button style
        style.configure("TButton",
                        background='red',
                        foreground='white',
                        font=('arial', 8, 'bold'),
                        relief='raised')

        # Add the exit button as a child to the plot frame:
        exit_button = ttk.Button(self, text="X", command=self.close, style="TButton")
        exit_button.place(relx=1, rely=0, width=27, height=27, anchor='ne')

        self.update_plot()

    def add_datapoint(self, data_row):
        if self.lat_label in data_row and self.lng_label in data_row:
            lat = data_row[self.lat_label]
            lng = data_row[self.lng_label]
            self.queue.put((lat, lng))

    def update_plot(self):
        while not self.queue.empty():
            lat, lng = self.queue.get()
            self.update_location(lat, lng)
        self.after(200, self.update_plot)  # Refresh every 200 milliseconds

    def create_marker(self, lat, lng, text):
        return self.map_frame.set_marker(lat, lng, text=text)

    def update_location(self, lat, lng):
        marker = self.create_marker(lat, lng, f"{lat}, {lng}")

        self.coordinates_list.append({'coords': (lat, lng), 'marker': marker})

        if len(self.coordinates_list) > 10:
            old_info = self.coordinates_list.pop(0)
            old_marker = old_info['marker']

            # Remove the marker's position from the path if it has been created
            if self.path is not None:
                self.path.remove_position(*old_marker.position)

            # Remove the old marker from the map
            self.map_frame.delete(old_marker)

        # Initiate the path or update it when we have at least two coordinates
        if len(self.coordinates_list) >= 2:
            if self.path is None:
                # Create the path with the first two coordinates
                self.path = self.map_frame.set_path([item['marker'].position for item in self.coordinates_list[:2]])
            else:
                # Or update the path if it already exists
                self.path.set_position_list([item['marker'].position for item in self.coordinates_list])

        self.update_counter += 1
        if self.update_counter >= 5:
            self.map_frame.set_position(lat, lng)
            self.update_counter = 0

    def reset_df(self):
        return

    def close(self):
        # Find the corresponding plot_info for the current plot
        plot_info_to_remove = next((plot_info for plot_info in self.main_obj.plots if plot_info['plot'] == self), None)

        # If the corresponding plot_info is found, remove it
        if plot_info_to_remove is not None:
            self.main_obj.plots.remove(plot_info_to_remove)

            # Retrieve the coordinates of the removed plot
            min_i, max_i, min_j, max_j = plot_info_to_remove['coordinates']

            # Display the corresponding grid buttons in the main class
            for i in range(min_i, max_i + 1):
                for j in range(min_j, max_j + 1):
                    self.main_obj.cell_buttons[i][j].grid()

        self.destroy()  # destroys the frame that holds the plot and the exit button