import serial
import serial.tools.list_ports
from datetime import datetime, timedelta
import re
import time
import pandas as pd
import os
from tkinter import filedialog, messagebox
import shutil
import requests
from pymongo.errors import PyMongoError



class SerialPort:
    def __init__(self, main_obj):
        self.main_obj = main_obj
        self.ser = None
        self.running = True  # Flag to control the running of threads
        self.all_sub_sensors = [{'id': '14', 'measuring_unit': 'dBm', 'type': 'RSSI'},
                                {'id': '15', 'measuring_unit': 'dB', 'type': 'SNR'},
                                {'id': '16', 'measuring_unit': 'Hz', 'type': 'Packet Frequency Error'}]

        new_sub_sensors = self.retrieve_all_sub_sensors()
        if new_sub_sensors:
            self.all_sub_sensors.extend(new_sub_sensors)

        print(self.all_sub_sensors)

    def retrieve_all_sub_sensors(self):
        response = requests.get("http://127.0.0.1:8080/fetch_all_sub_sensors")
        if response.status_code == 200:
            sub_sensors = response.json()
            if not sub_sensors:
                print(f"No sub sensors found for sensors")
            return sub_sensors
        else:
            print(f"Error fetching sub sensor names: HTTP {response.status_code}")
        return None

    def get_id_with_names(self, data_row):
        data_id_names_row = {}

        # add the keys to data_id_names_row if they exist in data_row
        for key in ["Date Time", "Elapsed Time", "Time (sec)"]:
            if key in data_row:
                data_id_names_row[key] = data_row[key]

        for item_dict in self.all_sub_sensors:
            if item_dict["id"] in data_row:
                data_id_names_row[f"ID: {item_dict['id']} {item_dict['type']} {item_dict['measuring_unit']}"] = \
                    data_row[item_dict['id']]

        return data_id_names_row

    def open_serial_port(self):
        ports = serial.tools.list_ports.comports()  # get list of available ports
        for port in ports:
            while True:  # loop until we successfully connect or exhaust tries
                try:
                    self.ser = serial.Serial(port.device, 9600, timeout=1)
                    print(f"Testing serial port: {port.device}")
                    raw = self.ser.readline().decode("utf-8", "ignore").strip()

                    match = re.search(r";([^\x2C]+),(-?[0-9]*\.?[0-9]+)", raw)
                    if match is not None:
                        print(f"Successfully opened serial port: {port.device}")
                        return
                    else:
                        print(f"Data from {port.device} does not match the expected format.")
                        self.ser.close()
                        break


                except (serial.serialutil.SerialException, AttributeError):
                    print(f"Could not open port {port.device}. Retrying in 5 seconds...")
                    time.sleep(1)  # wait for 1 second
                    continue  # retry opening the serial port

                except Exception as e:
                    print(f"Error reading from port {port.device}: {str(e)}")
                    self.ser.close()
                    break  # Exit the while loop and try next port

        self.ser = None  # Exception("No compatible serial port found.")

    def close_serial_port(self):
        if self.ser is not None:
            print("Closing serial port")
            self.ser.close()

    def read_from_port(self):
        """Read from serial port and enqueue the messages"""

        if self.ser is None:
            print("No open serial port.")

        temp_file_name = "temp.csv"
        temp_file_path = os.path.join(self.main_obj.temp_folder, temp_file_name)

        # Loop to continuously try to read from the port
        while self.running:
            # Check if self.ser is None or closed. If so, attempt to open the port.
            if self.ser is None or not self.ser.isOpen():
                try:
                    self.open_serial_port()
                    time.sleep(1)
                except Exception as e:
                    print(f"Error opening serial port: {str(e)}. Retrying in 1 second.")
                    # time.sleep(1)
                    continue  # loop back to keep trying to open the port

            try:
                raw = self.ser.readline().decode("utf-8", "ignore").strip()
                # Check if data matches the expected format
                match = re.search(r";(-?[0-9]*\.?[0-9]+),(-?[0-9]*\.?[0-9]+)",
                                  raw)  # kan sikkert bruke self.match fra open port?
                if match is None:
                    if raw != "":
                        print("Improperly formatted data received. Ignoring.")
                    # time.sleep(1)  # idle for a second before the next iteration
                    continue

            except Exception as e:
                print(f"Error reading from port: {str(e)}")
                # time.sleep(1)  # idle for a second before the next iteration
                self.open_serial_port()
                continue

            elapsed_seconds = round((datetime.now() - self.main_obj.start_time).total_seconds())
            self.main_obj.elapsed_time = str(timedelta(seconds=elapsed_seconds))

            # Extract variable-value pairs from raw, using regex
            var_val_pairs = re.findall(r";(-?[0-9]*\.?[0-9]+),(-?[0-9]*\.?[0-9]+)", raw)
            data_row = {"Date Time": datetime.now(),
                        "Elapsed Time": self.main_obj.elapsed_time,
                        "Time (sec)": elapsed_seconds}

            for var, val in var_val_pairs:
                try:
                    if var == "Clock Time":
                        # Convert the valued associated with "packet_counter" to an integer
                        data_row[var] = val
                        print(type(val))
                    else:
                        # Convert the value to a float and store it in the temporary dictionary

                        data_row[var] = float(val)
                except ValueError:
                    print(f"Could not convert value: {val} to float.")

            data_row_keys = set(data_row.keys())
            sensor_row_keys = set(self.main_obj.sensor_row.keys())

            common_keys = data_row_keys & sensor_row_keys

            matched_row = {"Date Time": data_row["Date Time"].strftime("%H:%M:%S")}

            # Add the rest
            matched_row.update({self.main_obj.sensor_row[key]: data_row[key] for key in common_keys})

            # Add data_row to each plot"s queue
            for plot_info in self.main_obj.plots:
                plot = plot_info["plot"]
                plot.add_datapoint(matched_row)

            data_row_with_names = self.get_id_with_names(data_row)

            if not self.all_sub_sensors:
                data_row_df = pd.DataFrame(data_row, index=[0])
            else:
                # Convert the data_row to a DataFrame
                data_row_df = pd.DataFrame(data_row_with_names, index=[0])
                print(data_row_with_names)

            # Only concatenate if data_row_df is not empty
            if not data_row_df.empty:
                # Check if DataFrame is None (i.e., this is the first row of data)
                if self.main_obj.data is None:

                    try:
                        if self.main_obj.connected:
                            # Assuming "data_row_df" contains the DataFrame.
                            data_dict = data_row_df.to_dict("records")

                            # Insert collection
                            self.main_obj.my_collection.insert_many(data_dict)
                    except Exception as e:
                        print(f"Error occurred while inserting data into MongoDB: {str(e)}")

                    data_row_df["Date Time"] = datetime.now().strftime("%H:%M:%S")

                    # If so, initialize DataFrame with variable names from data_row
                    self.main_obj.data = data_row_df

                    # Add "formatted_date" at the beginning of the DataFrame
                    self.main_obj.data.insert(0, "Start Date", datetime.now().strftime("%Y.%m.%d"))
                    self.main_obj.data.insert(1, "Start Time", self.main_obj.start_time.strftime("%H:%M:%S"))
                    self.main_obj.data.insert(2, "End Date", datetime.now().strftime("%Y.%m.%d"))
                    self.main_obj.data.insert(3, "End Time", datetime.now().strftime("%H:%M:%S"))
                    self.main_obj.data.insert(4, "Total Elapse", self.main_obj.elapsed_time)

                else:
                    # update as string, and update "Total Elapse"
                    self.main_obj.data.at[0, "End Time"] = datetime.now().strftime("%H:%M:%S")
                    self.main_obj.data.at[0, "End Date"] = datetime.now().strftime("%Y.%m.%d")
                    self.main_obj.data.at[0, "Total Elapse"] = self.main_obj.elapsed_time

                    try:
                        if self.main_obj.connected:
                            # Assuming "data_row_df" contains the DataFrame.
                            data_dict = data_row_df.to_dict("records")
                            # Insert collection
                            self.main_obj.my_collection.insert_many(data_dict)

                    except Exception as e:
                        print(f"Error occurred while inserting data into MongoDB: {str(e)}")

                    data_row_df["Date Time"] = data_row_df["Date Time"].dt.strftime("%H:%M:%S")
                    # Update Time Seconds
                    data_row_df["Time (sec)"] = elapsed_seconds

                    # Concatenating the new data row DataFrame with the existing DataFrame
                    self.main_obj.data = pd.concat([self.main_obj.data, data_row_df], ignore_index=True)

            # Save data to temporary CSV file with separator as ;
            if self.main_obj.data is not None:
                temp_data = self.main_obj.data.copy()
                temp_data.to_csv(temp_file_path, index=False, sep=";")
            else:

                print('main_obj.data is None')

    def send_uplink_command(self, command):
        """
        Sends an uplink command to the satellite via the serial port.

        Args:
            command (str): The command to be sent.
        """
        if self.ser is None or not self.ser.isOpen():
            raise Exception('Serial port is not open')
        command_bytes = bytes(command, 'utf-8')
        print("The entered command is: ", command)
        self.ser.write(command_bytes)


class FileManagement:
    def __init__(self, main_obj):
        self.main_obj = main_obj
        self.output_mongodb = ""

        if not os.path.exists(self.main_obj.temp_folder):
            # create a temporary folder if it doesn"t exist
            os.makedirs(self.main_obj.temp_folder, exist_ok=True)
        else:
            # Notify user if there are existing files in temporary directory
            self.notify_if_temp_files_exist()

    def notify_if_temp_files_exist(self):
        if os.listdir(self.main_obj.temp_folder):
            messagebox.showwarning("Warning", "There are files in the temporary directory. Please ensure "
                                              "they are removed or backed up as required before proceeding.")
            self.save_file_dialog()

    def save_file_dialog(self):
        if not os.path.exists(self.main_obj.temp_folder) or not os.listdir(self.main_obj.temp_folder):
            return

        file_output = filedialog.asksaveasfilename(defaultextension=".csv",
                                                   filetypes=[("CSV files", "*.csv")])
        if file_output:
            print("to be merged")
            self.main_obj.output_file = file_output
            self.merge_files()
        else:
            print("File merging cancelled: no file path chosen.")
            self.delete_from_mongo_db()

    def save_mongodb_dialog(self):
        self.output_mongodb = filedialog.asksaveasfilename(defaultextension=".csv",
                                                        filetypes=[("CSV files", "*.csv")])
        if self.output_mongodb:
            print("output chosen for mongodb database.")
        else:
            print("File merging cancelled: no file path chosen.")

    def merge_files(self):
        if not os.path.exists(self.main_obj.temp_folder) or not os.listdir(self.main_obj.temp_folder):
            return

        all_dfs = []
        column_headers = []  # List to hold all column headers

        for filename in os.listdir(self.main_obj.temp_folder):
            if filename.endswith(".csv"):
                file_path = os.path.join(self.main_obj.temp_folder, filename)

                # Check if the file is not empty
                if os.stat(file_path).st_size != 0:
                    df = pd.read_csv(file_path, delimiter=";")
                    all_dfs.append(df)
                    # Prefix columns with filename or other identifier to ensure uniqueness
                    prefixed_columns = [col for col in df.columns]
                    column_headers.extend(prefixed_columns)
                else:
                    print(f"The file {file_path} is empty and will be skipped.")

        if not all_dfs:
            return

        # Find the maximum number of rows and total columns needed
        max_rows = max(df.shape[0] for df in all_dfs)
        total_columns = sum(df.shape[1] for df in all_dfs)

        # Initialize a DataFrame with placeholders
        combined_df = pd.DataFrame(index=range(max_rows), columns=range(total_columns), dtype=str).fillna("")

        # Populate the combined DataFrame
        current_col = 0
        for df in all_dfs:
            rows, cols = df.shape
            combined_df.iloc[:rows, current_col:current_col + cols] = df.values
            current_col += cols

        # reset self.main_obj.data
        self.main_obj.data = None

        for plot_info in self.main_obj.plots:
            plot = plot_info["plot"]
            plot.reset_df()

        # Assign the collected column headers to the combined DataFrame
        combined_df.columns = column_headers

        combined_df.to_csv(self.main_obj.output_file, index=False, sep=";")

        # Cleanup
        shutil.rmtree(self.main_obj.temp_folder)
        os.makedirs(self.main_obj.temp_folder, exist_ok=True)

        try:
            if self.main_obj.connected:
                self.save_into_mongo_db()
        except Exception as e:
            print(f"Error occurred while inserting data into MongoDB: {str(e)}")

        # Resets the timer
        self.main_obj.start_time = datetime.now()

    def save_into_mongo_db(self):
        print("Saving data to MongoDB...")
        filename = os.path.splitext(os.path.basename(self.main_obj.output_file))[0]
        print(filename)
        # Create a new document
        doc = {
            "Filename": filename,
            "Start Date": self.main_obj.start_time,
            "End Date": datetime.now(),
            "Total Elapse": str(self.main_obj.elapsed_time)  # Saving elapsed_time as a string
        }

        # Insert the document into the collection
        self.main_obj.my_collection.insert_one(doc)

    def delete_from_mongo_db(self, filename=None):
        print("Deleting data from MongoDB...")
        if filename:
            name_and_date_doc = self.main_obj.my_collection.find_one({"Filename": filename})

            if name_and_date_doc is None:
                print(f"No documents found with filename {filename}.")
                return

            start_date = name_and_date_doc["Start Date"]
            end_date = name_and_date_doc["End Date"]

            # Delete the document matching the filename
            if self.main_obj.my_collection is not None:
                self.main_obj.my_collection.delete_one({"Filename": filename})
        else:
            start_date = self.main_obj.start_time
            end_date = datetime.now()

        # Check whether the my_collection is not None
        if self.main_obj.my_collection is not None:
            res = self.main_obj.my_collection.delete_many({"Date Time": {"$gte": start_date, "$lte": end_date}})
            print(f"Deleted {res.deleted_count} documents")
        else:
            print("Cannot delete entries from None collection.")

    def export_from_mongo_db(self, filename):
        self.output_mongodb = ''
        print(filename)
        self.save_mongodb_dialog()
        if self.output_mongodb == '':
            return

        name_and_date_doc = self.main_obj.my_collection.find_one({"Filename": filename})

        start_date = name_and_date_doc["Start Date"]
        end_date = name_and_date_doc["End Date"]

        between_data = list(self.main_obj.my_collection.find({"Date Time": {"$gte": start_date, "$lte": end_date}}))

        if not between_data:
            print("No data found for")
            return "No documents between the two instances found."

        df_fde = pd.DataFrame([name_and_date_doc]).drop("_id", axis=1)
        df_fde["Start Date"] = df_fde["Start Date"].dt.strftime("%Y.%m.%d")
        df_fde["End Date"] = df_fde["End Date"].dt.strftime("%Y.%m.%d")

        df = pd.DataFrame(between_data).drop("_id", axis=1)
        df["Date Time"] = df["Date Time"].dt.strftime("%H:%M:%S")

        df = pd.concat([df_fde, df], axis=1)
        df.to_csv(self.output_mongodb, sep=';', index=False)

        return f"Export to '{self.output_mongodb}' completed."

    def get_all_saved_instances(self):
        if self.main_obj.my_collection is None:
            print('my_collection not initialized yet')
            return None
        try:
            # Query the collection and transform it into a list
            docs = list(self.main_obj.my_collection.find({},
                                           {"_id": 0, "Filename": 1, "Start Date": 1, "End Date": 1,
                                             "Total Elapse": 1}).sort("Start Date", 1))
            # Remove any empty dictionaries from the list before returning
            docs = [doc for doc in docs if doc]

            # If the resulting list is empty, return None
            if not docs:
                return None
            else:
                return docs
        except PyMongoError as e:
            print(f"Unable to retrieve documents: {e}")
            return None
