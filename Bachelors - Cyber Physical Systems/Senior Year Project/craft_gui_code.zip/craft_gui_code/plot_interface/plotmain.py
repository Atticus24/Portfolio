import tkinter as tk
import tkinter.ttk as ttk
import datetime
import customtkinter as ctk
from plot_interface.serial_save import SerialPort, FileManagement
from plot_interface.plotmodule import GraphPlot, TablePlot, GpsPlot  # The RealtimePlot class will need to be able to handle grid as well.
import shutil
import threading
import numpy as np
import importlib
import pymongo
from pymongo.errors import PyMongoError
import requests
from db_credentials import mongodb_credentials

class PlotInterface(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        self.configure_plot = None

        self.connected = False
        self.db = None
        self.my_collection = None

        self.sensor_row = {"Date Time": "Date Time",
                           "14": "RSSI dBm",
                           "15": "SNR dB",
                           "16": "Packet Frequency Error Hz"
                           }
        self.plots = []
        self.plot_count = 0
        self.temp_folder = "temp_files"
        self.output_file = ""
        self.data = None
        self.start_time = datetime.datetime.now()
        self.elapsed_time = 0
        self.SerialPort = SerialPort(self)
        self.FileManagement = FileManagement(self)

        self.read_thread = threading.Thread(target=self.SerialPort.read_from_port)
        self.read_thread.start()

        ttk.Style().theme_use("clam")

        self.main_frame = tk.Frame(self)
        self.main_frame.pack(fill="both", expand=True)

        self.selected_button_style = ttk.Style()

        self.selected_button_style.configure("Selected.TButton",
                                             foreground="grey",
                                             background="#FAE5D3",
                                             bordercolor="#F5CBA7",
                                             lightcolor="#F5CBA7",
                                             darkcolor="#F5CBA7")

        self.selected_button_style.map("Selected.TButton",
                                       background=[("active", "#F0B27A")],
                                       bordercolor=[("active", "#F39C17")],
                                       lightcolor=[("active", "#FCA31A")],
                                       darkcolor=[("active", "#DE8E13")])

        self.grid_button_style = ttk.Style()

        self.grid_button_style.configure("Grid.TButton",
                                         foreground="grey",
                                         background="grey80",
                                         bordercolor="grey70",
                                         lightcolor="grey65",
                                         darkcolor="grey60")

        self.grid_button_style.map("Grid.TButton",
                                   background=[("active", "#F0B27A")],
                                   bordercolor=[("active", "#F39C17")],
                                   lightcolor=[("active", "#FCA31A")],
                                   darkcolor=[("active", "#DE8E13")])

        self.button_frame = tk.Frame(self.main_frame)
        self.button_frame.pack(anchor='n', fill="x", expand=True)

        # Go back button (small and at top-left)
        self.button_top_left_frame = tk.Frame(self.button_frame)
        self.button_top_left_frame.pack(side="left")

        # Load and resize the image
        self.go_back_img = tk.PhotoImage(file="craft_gui_go_back_button.png")
        self.go_back_img = self.go_back_img.subsample(2, 2)  # Reduce image size by half as an example.

        self.go_back_button = tk.Button(
            self.button_top_left_frame,
            image=self.go_back_img,
            borderwidth=0,
            highlightthickness=0,
            command=self.go_back,
        )

        self.go_back_button.pack(padx=5, pady=5)
        self.go_back_button.image = self.go_back_img  # Keep a reference

        # Save button (Left)
        self.button_left_frame = tk.Frame(self.button_frame)
        self.button_left_frame.pack(side="left")

        self.save_button = ctk.CTkButton(self.button_left_frame,
                                         text="Choose Save Location",
                                         font=("Helvetica", 13),
                                         fg_color="orange",
                                         text_color="black",
                                         corner_radius=8,
                                         border_width=3,
                                         border_color="black",
                                         hover_color="DarkOrange2",
                                         height=30,
                                         width=150,
                                         command=self.FileManagement.save_file_dialog)
        self.save_button.pack()

        # Add New button (Top-Center)
        self.button_center_frame = tk.Frame(self.button_frame)
        self.button_center_frame.pack(side="left", expand=True)

        self.add_plot_button = ctk.CTkButton(self.button_center_frame,
                                             text="Add New",
                                             font=("Helvetica", 13),
                                             fg_color="orange",
                                             text_color="black",
                                             corner_radius=8,
                                             border_width=3,
                                             border_color="black",
                                             hover_color="DarkOrange2",
                                             height=30,
                                             width=150)
        self.add_plot_button.bind("<Button-1>", self.open_plot_options)
        self.add_plot_button.pack(side="right")

        # Send Command button (Top-Right)
        self.button_right_frame = tk.Frame(self.button_frame)
        self.button_right_frame.pack(side="right")

        self.satellite_cmd_button = ctk.CTkButton(
            self.button_right_frame,
            text="Send command to satellite",
            font=("Helvetica", 13),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            height=30,
            width=225,
            command=self.open_satellite_cmd_input)
        self.satellite_cmd_button.pack(side="right")

        self.grid_frame = tk.Frame(self.main_frame, bg="white")

        self.grid_frame.pack(fill="both", expand=True)

        self.sensor_from_config = [("14", "RSSI", "dBm"),
                                   ("1", "Gyrocope (x)", "deg"),
                                   ("5", "Gyroscope (y)", "deg"),
                                   ("6", "Gyroscope (z)", "deg"),
                                   ("10", "MPU Temperatur", "Celcius"),
                                   ("11", "BMP Temperatur", "Celcius"),
                                   ("10", "Pressure", "Pascal"),
                                   ("13", "NTC Temperatur", "Kelvin"),
                                   ("2", "Accelerometer (x)", "m/s^2"),
                                   ("3", "Accelerometer (y)", "m/s^2"),
                                   ("4", "Accelerometer (z)", "m/s^2"),
                                   ("7", "Magnetometer (x)", "Tesla"),
                                   ("8", "Magnetometer (y)", "Tesla"),
                                   ("9", "Magnetometer (z)", "Tesla")]

        self.plot_option_frame = tk.Frame(self.main_frame)
        self.dropdown_frame = tk.Frame(self.main_frame)

        self.plot_options = {}
        self.plot_option_buttons = []


        self.grid_points = []  # To store the grid points (start, end)

        self.line_colors = ["b", "r", "c", "m", "y", "k"]

        # Initialize selected_plot
        self.selected_plot = None
        self.selected_plot = None
        self.selected_table = False
        self.selected_gps = False
        self.plot_confirmation = False

        self.table_list = None

        self.last_button_pressed = ""

        self.on_show = True

    def on_show_frame(self):
        if self.on_show:
            self.after(100, self.make_button_grid)  # Calls the function to make the grid of tkinter buttons
            self.on_show = False

        self.set_sensor_dict()
        self.setup_plot_options()
        self.hide_frames()

    def connect_to_mongodb(self, user_email):
        try:
            client = pymongo.MongoClient(
                mongodb_credentials,
                serverSelectionTimeoutMS=1000)
            client.server_info()  # This line will raise an error if the connection failed
            self.db = client.sensor_data
            group_name = self.get_group_name(user_email)
            print(user_email)
            print(group_name)

            if group_name is None:
                print("Group name could not be retrieved. Defaulting to 'no_group'.")
                group_name = 'no_group'

            self.my_collection = self.db[group_name]
            self.connected = True

        except pymongo.errors.ServerSelectionTimeoutError as err:
            print("Unable to connect to MongoDB server")

    def get_group_name(self, user_email):
        response = requests.get(f"http://127.0.0.1:8080/fetch_group_name/{user_email}")
        if response.status_code == 200:
            group_name = response.text  # Because endpoint returns a string
            return group_name
        else:
            print(f"Error fetching group name: HTTP {response.status_code}")
            return None

    def go_back(self):
        main_module = importlib.import_module("__main__")
        ConfigurePlot = getattr(main_module, "ConfigurePlot")
        self.controller.show_frame(ConfigurePlot)

    def set_config_sensors(self, config_sensors):
        self.sensor_from_config = config_sensors

    def send_command_to_satellite(self):
        # Check if a custom command should be set
        if self.last_button_pressed == "":
            command = self.satellite_command.get()
        else:
            # Build the command string using the last pressed button and the input field
            command = self.last_button_pressed + ", " + self.satellite_command.get() + ";"
        print("The entered command is: ", command)

        self.SerialPort.send_uplink_command(command)

        # Updating "Sent!" label
        self.sent_label.config(text=f"{command} is Sent!")

        self.after(2000, lambda: self.sent_label.config(text=""))  # removing the "Sent!" after 2 seconds

    def place_command_in_input(self, cmd, desc):
        # Update the 'last_button_pressed' attribute with the label of the pressed button
        self.last_button_pressed = cmd
        # Update the command_label and command_description_lbl
        self.command_label.config(text=f"{cmd}, ")
        self.semicolon_label = tk.Label(self.command_frame, text=";")
        self.command_description_lbl.config(text=desc)

    def open_satellite_cmd_input(self):
        print("Opening satellite")
        # list of commands and their descriptions
        commands = {
            "BEEP": "Turns the buzzer on for 10 seconds with the frequency provided.",
            "BAND": "Sets the radio bandwidth on the satellite. For allowed frequencies see begin function.",
            "FREQ": "Sets the radio frequency on the satellite. All SX127X frequencies allowed.",
            "TXP": "Sets the radio transmission power on the satellite. Allowed values: 2-20dBm.",
            "SF": "Sets the radio spreading factor on the satellite. Allowed values: 6-12.",
            "CR": "Sets the radio coding rate on the satellite. Allowed values: 5-8."
        }

        if hasattr(self, "plot_option_frame"):
            self.plot_option_frame.destroy()
        self.plot_option_frame = tk.Frame(self.main_frame)
        self.plot_option_frame.place(relx=0.5, rely=0.5, anchor="center")

        # Creation of exit button
        exit_button = tk.Button(self.plot_option_frame, text="X", command=self.plot_option_frame.destroy)
        exit_button.pack(anchor='ne')  # put it at top-right corner

        self.command_description_lbl = tk.Label(self.plot_option_frame, text="")
        self.command_description_lbl.pack()

        # New frame for COMMAND, input field, and ;
        self.command_frame = tk.Frame(self.plot_option_frame)
        self.command_frame.pack()

        self.command_label = tk.Label(self.command_frame, text="COMMAND, ")
        self.command_label.grid(row=0, column=0)

        self.satellite_command = tk.StringVar()
        cmd_input = tk.Entry(self.command_frame, textvariable=self.satellite_command)
        cmd_input.grid(row=0, column=1)

        self.semicolon_label = tk.Label(self.command_frame, text=";")
        self.semicolon_label.grid(row=0, column=2)

        send_button = tk.Button(
            self.plot_option_frame,
            text="Send Command",
            command=self.send_command_to_satellite)
        send_button.pack(pady=10)

        # Create a new frame for command buttons
        self.command_button_frame = tk.Frame(self.plot_option_frame)
        self.command_button_frame.pack()  # pack under the send button

        custom_command_button = tk.Button(
            self.plot_option_frame,
            text="Custom Command",
            command=self.load_custom_command)
        custom_command_button.pack(pady=10)

        for command, description in commands.items():
            text = command
            btn = tk.Button(
                self.command_button_frame,
                text=text,
                command=lambda cmd=text, desc=description: self.place_command_in_input(cmd, desc)
            )
            btn.pack(side="left", padx=5)

        self.sent_label = tk.Label(self.plot_option_frame, text="")
        self.sent_label.pack()

    def load_custom_command(self):
        # Hide the label widgets by setting their text to empty
        self.command_label.config(text="")
        self.semicolon_label.config(text="")
        self.command_description_lbl.config(text="")
        # Setting the 'last_button_pressed' to an empty string
        self.last_button_pressed = ""

    def set_sensor_dict(self):
        for sensor in self.sensor_from_config:
            if len(sensor) == 4:
                sensor_id, name, prefix, unit = sensor
                self.sensor_row[sensor_id] = f"{name} {prefix}{unit}"
            elif len(sensor) == 3:
                sensor_id, name, unit = sensor
                self.sensor_row[sensor_id] = f"{name} {unit}"
            else:
                print("Invalid sensor")
        print(self.sensor_row)

    def setup_plot_options(self):
        buttons = ["Graph Plot", "Table Plot", "GPS Plot"]
        button_commands = [self.open_graph_options, self.open_table_options, self.open_gps]

        self.plot_option_frame.config(background="grey80", highlightbackground="black", highlightthickness=2)

        for i, button_text in enumerate(buttons):
            button = ctk.CTkButton(
                self.plot_option_frame,
                text=button_text,
                font=("Helvetica", 13),
                fg_color="orange",
                text_color="black",
                corner_radius=8,
                border_width=3,
                border_color="black",
                hover_color="DarkOrange2",
                height=30,
                width=150,
                command=button_commands[i])  # Adjusted this line

            button.pack(side=tk.LEFT, padx=10, pady=10)  # Added this line

    def setup_graph_options(self):

        if self.sensor_row is not None:
            columns = list(self.sensor_row.values())
            for col in columns:
                color = np.random.choice(self.line_colors)  # Randomly choose a color
                self.plot_options.update({col: [color, "Date Time", col]})

        self.plot_options.update({"Custom Plot": ["green", "Custom X-axis", "Custom Y-axis"]})

        self.plot_option_frame.config(background="grey80", highlightbackground="black", highlightthickness=2)

        i = 0  # counter
        row_frame = tk.Frame(self.plot_option_frame)  # Create the first row frame
        row_frame.config(background="grey80")

        for key, value in self.plot_options.items():
            if key != "Custom Plot" and key != "Date Time":
                button = ctk.CTkButton(row_frame,
                                       text=key,
                                       font=("Helvetica", 13),
                                       fg_color="orange",
                                       text_color="black",
                                       corner_radius=8,
                                       border_width=3,
                                       border_color="black",
                                       hover_color="DarkOrange2",
                                       height=30,
                                       width=150)
                button.pack(side=tk.LEFT, padx=10, pady=10)
                button.bind("<Button-1>", lambda event, k=key, v=value: self.accept_plot_creation(k, *v))
                self.plot_option_buttons.append(button)  # Add the button to the list.

                i += 1

                if i % 4 == 0:
                    row_frame.pack(pady=10)
                    row_frame = tk.Frame(self.plot_option_frame)
                    row_frame.config(background="grey80")

        row_frame.pack(pady=10)  # pack the final row_frame

        # Custom Plot button frame
        custom_button_frame = tk.Frame(self.plot_option_frame)
        custom_button_frame.pack(pady=10)
        custom_button_frame.config(background="grey80")

        custom_button = ctk.CTkButton(custom_button_frame,
                                      text="Custom Plot",
                                      font=("Helvetica", 13),
                                      fg_color="orange",
                                      text_color="black",
                                      corner_radius=8,
                                      border_width=3,
                                      border_color="black",
                                      hover_color="DarkOrange2",
                                      height=45,
                                      width=225)
        custom_button.pack(pady=10)
        custom_button.bind("<Button-1>", lambda event, k=key, v=value: self.accept_plot_creation(k, *v))
        self.plot_option_buttons.append(custom_button)  # Add the button to the list

    def setup_table_options(self):
        self.plot_option_frame.config(background="grey80", highlightbackground="black", highlightthickness=2)
        self.selected_columns = []  # to store the pressed buttons' names
        self.buttons = {}  # dictionary to hold button instances

        if self.sensor_row is not None:
            columns = list(self.sensor_row.values())

            i = 0  # counter
            row_frame = tk.Frame(self.plot_option_frame)  # Create the first row frame
            row_frame.config(background="grey80")

            for col in columns:
                if col != "Date Time":
                    button = ctk.CTkButton(row_frame,
                                           text=col,
                                           font=("Helvetica", 13),
                                           fg_color="orange",
                                           text_color="black",
                                           corner_radius=8,
                                           border_width=3,
                                           border_color="black",
                                           hover_color="DarkOrange2",
                                           height=30,
                                           width=150,
                                           command=lambda c=col: self.button_press(c))
                    button.pack(side=tk.LEFT, padx=10, pady=10)
                    self.buttons[col] = button  # Keep reference to the button

                    i += 1

                    if i % 4 == 0:  # Adjust the number to set how many buttons per row
                        row_frame.pack(pady=10)
                        row_frame = tk.Frame(self.plot_option_frame)
                        row_frame.config(background="grey80")

                row_frame.pack(pady=10)  # pack the final row_frame

        confirm_button_frame = tk.Frame(self.plot_option_frame)  # Button frame
        confirm_button_frame.pack(pady=10)
        confirm_button_frame.config(background="grey80")

        confirm_button = ctk.CTkButton(confirm_button_frame,
                                       text="Confirm",
                                       font=("Helvetica", 13),
                                       fg_color="orange",
                                       text_color="black",
                                       corner_radius=8,
                                       border_width=3,
                                       border_color="black",
                                       hover_color="DarkOrange2",
                                       height=45,
                                       width=225,
                                       command=self.accept_table_creation)
        confirm_button.pack(pady=10)

    def button_press(self, col):
        button = self.buttons[col]  # Access the button from dictionary

        if col not in self.selected_columns:
            self.selected_columns.append(col)  # Adds the column to the selected list
            button.configure(fg_color="green")  # Changes button color to green
        else:
            self.selected_columns.remove(col)  # Removes the column from the selected list
            button.configure(fg_color="orange")  # Changes button color back to orange

    def setup_axis_dropdown(self, frame):
        self.x_axis_var = tk.StringVar()
        self.y_axis_var = tk.StringVar()

        self.x_label_dropdown = tk.Label(frame, text="X Axis:")
        self.y_label_dropdown = tk.Label(frame, text="Y Axis:")

        # initially hide the labels
        self.x_label_dropdown.pack_forget()
        self.y_label_dropdown.pack_forget()

        self.x_axis_dropdown = ttk.Combobox(frame, textvariable=self.x_axis_var, state="disabled")
        self.y_axis_dropdown = ttk.Combobox(frame, textvariable=self.y_axis_var, state="disabled")

        # initially hide the dropdown menus
        self.x_axis_dropdown.pack_forget()
        self.y_axis_dropdown.pack_forget()

    def open_plot_options(self, _event):
        # destroy the old frame if it exists, and create a new one
        if hasattr(self, "plot_option_frame"):
            self.plot_option_frame.destroy()
        self.plot_option_frame = tk.Frame(self.main_frame)

        # Hide dropdown_frame and show plot_option_frame when "Add Plot" button is clicked
        self.dropdown_frame.place_forget()
        self.plot_option_frame.place(relx=0.5, rely=0.5, anchor="center")

        self.setup_plot_options()  # set up content of the frame

    def open_graph_options(self):
        # destroy the old frame if it exists, and create a new one
        if hasattr(self, "plot_option_frame"):
            self.plot_option_frame.destroy()
        self.plot_option_frame = tk.Frame(self.main_frame)

        # Hide dropdown_frame and show plot_option_frame when "Add Plot" button is clicked
        self.dropdown_frame.place_forget()
        self.plot_option_frame.place(relx=0.5, rely=0.5, anchor="center")

        self.setup_graph_options()  # set up content of the frame

    def open_table_options(self):
        # destroy the old frame if it exists, and create a new one
        if hasattr(self, "plot_option_frame"):
            self.plot_option_frame.destroy()
        self.plot_option_frame = tk.Frame(self.main_frame)

        # Hide dropdown_frame and show plot_option_frame when "Add Plot" button is clicked
        self.dropdown_frame.place_forget()
        self.plot_option_frame.place(relx=0.5, rely=0.5, anchor="center")

        self.setup_table_options()  # set up content of the frame

    def open_gps(self):
        # destroy the old frame if it exists, and create a new one
        if hasattr(self, "plot_option_frame"):
            self.plot_option_frame.destroy()
        self.plot_option_frame = tk.Frame(self.main_frame)

        # Hide dropdown_frame and show plot_option_frame when "Add Plot" button is clicked
        self.dropdown_frame.place_forget()
        self.selected_gps = True

        self.confirm_plot()  # set up content of the frame

    def open_dropdown_frame(self):
        # destroy the old frame if it exists, and create a new one
        if hasattr(self, "dropdown_frame"):
            self.dropdown_frame.destroy()
        self.dropdown_frame = tk.Frame(self.main_frame, background="grey80", highlightbackground="black",
                                       highlightthickness=2)

        # Hide plot_option_frame and show dropdown_frame
        self.plot_option_frame.place_forget()
        self.dropdown_frame.place(relx=0.5, rely=0.5, anchor="center")

    def hide_frames(self):
        # forget the dropdown_frame, if it exists
        if hasattr(self, "dropdown_frame"):
            self.dropdown_frame.place_forget()

        # forget the plot_option_frame
        if hasattr(self, "plot_option_frame"):
            self.plot_option_frame.place_forget()

        # Destroy x and y axis dropdowns, their labels, and confirm_button if they exist
        if hasattr(self, "x_axis_dropdown"):
            self.x_axis_dropdown.destroy()
            del self.x_axis_dropdown
        if hasattr(self, "x_label_dropdown"):
            self.x_label_dropdown.destroy()
            del self.x_label_dropdown
        if hasattr(self, "y_axis_dropdown"):
            self.y_axis_dropdown.destroy()
            del self.y_axis_dropdown
        if hasattr(self, "y_label_dropdown"):
            self.y_label_dropdown.destroy()
            del self.y_label_dropdown
        if hasattr(self, "confirm_button"):
            self.confirm_button.destroy()
            del self.confirm_button

    def confirm_plot(self):

        # Now hide the plot options frame
        self.hide_frames()

        self.plot_confirmation = True

    def accept_plot_creation(self, title, color, x_label, y_label, ):
        if title != "Custom Plot":
            self.selected_plot = (
                title, color, x_label, y_label)
            self.confirm_plot()
            return

        self.open_dropdown_frame()

        # Creating a new frame for dropdown menus
        self.dropdown_frame = tk.Frame(self, background="grey80", highlightbackground="black", highlightthickness=2)
        self.dropdown_frame.place(relx=0.5, rely=0.5, anchor="center")

        # Move the plot option buttons logic to the new dropdown_frame
        for button in self.plot_option_buttons:  # hide plot options
            button.pack_forget()

        # Setup dropdown menus in the new frame
        if self.sensor_row is not None:
            self.setup_axis_dropdown(
                self.dropdown_frame)  # calling setup_axis_dropdown() after a plot option is clicked
            columns = list(self.sensor_row.values())
            self.x_axis_var.set(columns[0])
            self.y_axis_var.set(columns[0])
            self.x_axis_dropdown["values"] = columns
            self.y_axis_dropdown["values"] = columns
            self.x_axis_dropdown.config(state="readonly")
            self.y_axis_dropdown.config(state="readonly")

        self.confirm_button = ttk.Button(self.dropdown_frame, text="Confirm Plot", command=self.confirm_plot)
        # initially hide the confirm button
        self.confirm_button.pack_forget()

        # when a plot option is selected, show the labels, dropdown menus and confirm button
        self.x_label_dropdown.pack()
        self.x_axis_dropdown.pack()
        self.y_label_dropdown.pack()
        self.y_axis_dropdown.pack()
        self.confirm_button.pack()

        self.selected_plot = (title, color, x_label, y_label)

    def accept_table_creation(self):
        self.table_list = self.selected_columns  # Use the updated selected columns
        print(self.table_list)
        self.selected_table = True
        self.confirm_plot()

    def make_button_grid(self):
        self.grid_size = 100  # Set the grid size to create bigger buttons

        rows = self.winfo_height() // self.grid_size
        columns = self.winfo_width() // self.grid_size

        # Configure the grid cells to adjust their size with window size
        for i in range(rows):
            self.grid_frame.grid_rowconfigure(i, weight=1, minsize=self.grid_size)
        for j in range(columns):
            self.grid_frame.grid_columnconfigure(j, weight=1, minsize=self.grid_size)

        self.cell_buttons = [[None for _ in range(columns)] for __ in range(rows)]

        for i in range(rows):
            for j in range(columns):
                button = ttk.Button(self.grid_frame, style="Grid.TButton")
                button.grid(row=i, column=j, sticky="nsew")  # added padding for space between buttons
                self.cell_buttons[i][j] = button

                button.configure(command=lambda x=i, y=j: self.select_cell(x, y))
                button.bind("<Enter>", lambda event, x=i, y=j: self.preview_square(x, y))

    def select_cell(self, i, j):
        # Check if a plot has been confirmed before processing grid selection
        if not self.plot_confirmation:
            return

        # if self.selected_plot:  # Only works if a plot has been selected
        # If it"s the first selection, make the button appear selected
        if len(self.grid_points) == 0:
            self.cell_buttons[i][j].configure(style="Selected.TButton")
            self.grid_points.append((i, j))

        elif len(self.grid_points) == 1:  # If it"s the second selection
            if self.grid_points[0] == (i, j):  # Don"t allow the selection of the same cell twice
                return

            self.cell_buttons[i][j].configure(style="Selected.TButton")
            self.grid_points.append((i, j))

            if len(self.grid_points) < 2:  # If less than 2 points selected then do not proceed
                return

            # Fetch number of rows and columns by checking the shape of self.cell_buttons matrix
            rows = len(self.cell_buttons)
            columns = len(self.cell_buttons[0]) if rows > 0 else 0

            # Unhighlight all cells for re-evaluation
            for x in range(rows):
                for y in range(columns):
                    self.unhighlight_cell(x, y)

            # Redraw highlight over selected cells (creates the plot area rectangle)
            i1, j1 = self.grid_points[0]
            i2, j2 = self.grid_points[1]
            min_i, max_i = sorted([i1, i2])
            min_j, max_j = sorted([j1, j2])

            # Change the state of all buttons within the rectangle
            for x in range(min_i, max_i + 1):
                for y in range(min_j, max_j + 1):
                    self.cell_buttons[x][y].configure(style="Selected.TButton")

            # Create the plot
            self.generate_plot_from_cells()

            # Clear the selected plot and selected cells to allow for new selection
            self.grid_points = []
            self.selected_plot = None
            self.selected_table = False
            self.selected_gps = False

    def preview_square(self, i, j):
        rows = len(self.cell_buttons)
        columns = len(self.cell_buttons[0]) if rows > 0 else 0

        for x in range(rows):
            for y in range(columns):
                self.unhighlight_cell(x, y)

        if len(self.grid_points) > 0:
            i1, j1 = self.grid_points[0]
            min_i, max_i = sorted([i, i1])
            min_j, max_j = sorted([j, j1])
            flag_x = True
            flag_y = True

            for x in range(min_i, max_i + 1):
                if self.is_overlapping_point(x, j1):
                    flag_x = False
            for y in range(min_j, max_j + 1):
                if self.is_overlapping_point(i1, y):
                    flag_y = False

            for x in range(min_i, max_i + 1):
                for y in range(min_j, max_j + 1):
                    if flag_x and flag_y:
                        if not self.is_overlapping_point(x, y):
                            self.highlight_cell(x, y)
                    elif flag_x and not flag_y:
                        if not self.is_overlapping_point(x, j1):
                            self.highlight_cell(x, j1)
                    elif not flag_x and flag_y:
                        if not self.is_overlapping_point(i1, y):
                            self.highlight_cell(i1, y)

    def highlight_cell(self, i, j):
        # Apply the effect only between the first and second click
        if len(self.grid_points) == 1:
            i1, j1 = self.grid_points[0]
            min_i, max_i = sorted([i, i1])
            min_j, max_j = sorted([j, j1])
            # Check if the cell is within the rectangle from self.grid_points[0] to (i, j)
            if min_i <= i <= max_i and min_j <= j <= max_j:
                self.cell_buttons[i][j].configure(style="Selected.TButton")

    def unhighlight_cell(self, i, j):

        # Remove the effect only between the first and second click
        if len(self.grid_points) == 1:
            self.cell_buttons[i][j].configure(style="Grid.TButton")

    def is_overlapping(self, min_i, max_i, min_j, max_j):
        for plot in self.plots:
            plot_min_i, plot_max_i, plot_min_j, plot_max_j = plot["coordinates"]
            if max_i < plot_min_i or min_i > plot_max_i or max_j < plot_min_j or min_j > plot_max_j:
                continue
            return True
        return False

    def is_overlapping_point(self, i, j):
        for plot in self.plots:
            plot_min_i, plot_max_i, plot_min_j, plot_max_j = plot["coordinates"]
            if not (plot_min_i <= i <= plot_max_i and plot_min_j <= j <= plot_max_j):
                continue
            return True
        return False

    def generate_plot_from_cells(self):

        i1, j1 = self.grid_points[0]
        i2, j2 = self.grid_points[1]

        min_i, max_i = sorted([i1, i2])
        min_j, max_j = sorted([j1, j2])

        if not self.is_overlapping(min_i, max_i, min_j, max_j):
            if self.selected_plot:
                title, color, x_label, y_label = self.selected_plot
                if title == "Custom Plot":
                    new_plot = GraphPlot(self.grid_frame, self, self.plot_count, title, color, self.x_axis_var.get(),
                                            self.y_axis_var.get(), min_i, max_i, min_j, max_j)
                else:
                    new_plot = GraphPlot(self.grid_frame, self, self.plot_count, title, color, x_label, y_label)

            if self.selected_table:
                new_plot = TablePlot(self.grid_frame, self, self.table_list)

            if self.selected_gps:
                new_plot = GpsPlot(self.grid_frame, self, "lat", "lng")

            new_plot.grid(row=min_i,
                          column=min_j,
                          rowspan=max_i - min_i + 1,
                          columnspan=max_j - min_j + 1,
                          sticky="nsew")

            plot_thread = threading.Thread(target=new_plot.update_plot)
            plot_thread.start()
            plot_info = {
                "plot": new_plot,
                "coordinates": (min_i, max_i, min_j, max_j),
                "thread": plot_thread,
            }
            self.plots.append(plot_info)  # store the plot along with its coordinates for future reference.

            for i in range(min_i, max_i + 1):
                for j in range(min_j, max_j + 1):
                    self.cell_buttons[i][j].grid_remove()

            self.plot_count += 1

        else:
            print("New plot overlaps with an existing one, please select a different area!")
        self.grid_points = []
        self.selected_plot = None

        # Reset plot confirmation to False after generating the plot.
        # This ensures the user must confirm using "Confirm Plot" button
        # for each new plot before selecting cells.
        self.plot_confirmation = False

    def on_destroy(self):
        # Call the save dialog
        self.FileManagement.save_file_dialog()

        # Set the running flag to False, stopping thread operations.
        self.SerialPort.running = False

        # Wait for the read thread to finish
        self.read_thread.join()

        # For each plot_info in self.plots, if a "thread" key exists and the thread is alive, stop the thread.
        for plot_info in self.plots:
            if "thread" in plot_info and plot_info["thread"].is_alive():
                plot_info["thread"].join()

        # If a serial port has been opened, close it.
        self.SerialPort.close_serial_port()

        shutil.rmtree(self.temp_folder)

        self.destroy()

    def on_closing(self):
        # Call the save dialog
        self.FileManagement.save_file_dialog()

        # Set the running flag to False, stopping thread operations.
        self.SerialPort.running = False

        # Wait for the read thread to finish
        self.read_thread.join()

        # For each plot_info in self.plots, if a "thread" key exists and the thread is alive, stop the thread.
        for plot_info in self.plots:
            if "thread" in plot_info and plot_info["thread"].is_alive():
                plot_info["thread"].join()

        # If a serial port has been opened, close it.
        self.SerialPort.close_serial_port()

        shutil.rmtree(self.temp_folder)


