credentials= {
    'host': "craftsql.mysql.database.azure.com",
    'user': "nathanael_getaneh",
    'password': "Craft2024",
    'database': "craftsql",
}

mongodb_credentials = "mongodb+srv://danielostmoen:MJc8oMQbzJPnzdF0@craftcluster.74eqtpc.mongodb.net/?retryWrites=true&w=majority&appName=CraftCluster"