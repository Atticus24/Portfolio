import tkinter as tk
from tkcalendar import Calendar
import threading
import customtkinter
import requests
from tkinter import PhotoImage
from PIL import Image, ImageTk
from tkinter import messagebox
from ctypes import windll
from urllib.parse import quote
from datetime import date
from datetime import datetime
from tkinter import ttk
import time
import qrcode
from plot_interface.plotmain import PlotInterface
import importlib
import pymongo
from pymongo.errors import PyMongoError
from tkinter import filedialog, messagebox
import pandas as pd
import os
import signal
from multiprocessing import Process
from app_backend import create_app
from db_credentials import mongodb_credentials

windll.shcore.SetProcessDpiAwareness(1)


class SampleApp(tk.Tk):  # intermediary when transitioning beween frames/pages.
    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)

        self.user_email = None
        self.last_user_email = None

        # Make container an instance variable.
        self.container = tk.Frame(self)
        self.container.pack(side="top", fill="both", expand=True)
        self.container.grid_rowconfigure(0, weight=1)
        self.container.grid_columnconfigure(0, weight=1)

        self.frames = {}  # dictionary

        for F in (
                Login,
                RegisterUser,
                WelcomePage,
                ViewOwnSatellites,
                ConfigurePlot,
                AdminEntry,
                Courses,
                Groups,
                Users,
                Sensors,
                Satellites
        ):
            frame = F(self.container, self)
            frame.configure(background="white")
            self.frames[F] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame(Login)

    def set_user_email(self, email):
        self.user_email = email

    def set_config_sensors(self, config_sensors):
        self.config_sensors = config_sensors

    def show_frame(self, cont):  # container
        frame = self.frames[cont]
        if self.user_email is not None and self.user_email != self.last_user_email:  # new user
            if cont == WelcomePage:
                if PlotInterface in self.frames:
                    self.frames[PlotInterface].on_destroy()
                    print("destroy")
                plot_interface_frame = PlotInterface(self.container, self)
                plot_interface_frame.grid(row=0, column=0, sticky="nsew")
                self.frames[PlotInterface] = plot_interface_frame
                self.frames[PlotInterface].connect_to_mongodb(self.user_email)

                if SaveHistory in self.frames:
                    self.frames[SaveHistory].destroy()
                save_history_frame = SaveHistory(self.container, self)
                save_history_frame.grid(row=0, column=0, sticky="nsew")
                self.frames[SaveHistory] = save_history_frame

                self.last_user_email = self.user_email

            if cont == AdminEntry:
                if PlotInterface in self.frames:
                    self.frames[PlotInterface].on_destroy()
                if SaveHistory in self.frames:
                    self.frames[SaveHistory].destroy()

                history_frame = SaveHistory(self.container, self)
                history_frame.grid(row=0, column=0, sticky="nsew")
                self.frames[SaveHistory] = history_frame

        if cont == PlotInterface:
            frame.set_config_sensors(self.config_sensors)
            frame.on_show_frame()

        frame.tkraise()
        print(f"{cont} frame raised")


class BasePage(tk.Frame):
    def __init__(self, parent, controller, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)
        self.controller = controller

        # Load images
        self.go_back_img = tk.PhotoImage(file="craft_gui_go_back_button.png")
        self.wifi_img = tk.PhotoImage(file="wifi img.png")

        # Top frame for logo and go back button
        self.top_frame = tk.Frame(self, bg="white")
        self.top_frame.grid(row=0, column=0, sticky="ew", columnspan=2)
        self.top_frame.grid_columnconfigure(1, weight=1)

        # Go back button
        self.go_back_button = tk.Button(
            self.top_frame,
            image=self.go_back_img,
            borderwidth=0,
            highlightthickness=0,
            command=self.go_back,
        )
        self.go_back_button.grid(row=0, column=0, padx=20, pady=10, sticky="w")
        self.go_back_button.image = self.go_back_img  # Keep a reference

        # Logo label
        logo_label = tk.Label(
            self.top_frame, text="C.R.A.F.T", font=("Helvetica", 46), bg="white"
        )
        logo_label.grid(row=0, column=1, padx=20, pady=10, sticky="w")

        # WiFi Label
        self.wifi_label = tk.Label(self.top_frame, image=self.wifi_img, bd=0)
        self.wifi_label.grid(row=0, column=7, padx=10, pady=10, sticky="e")

        # Welcome label
        self.welcome_label = tk.Label(
            self.top_frame,
            text="Welcome (first name, last name)",
            font=("Helvetica 16 underline"),
            bg="white",
        )
        self.welcome_label.grid(row=0, column=6, padx=10, pady=10, sticky="e")

        # Create a frame for the background image
        self.image_frame = tk.Frame(self, bg="white")
        self.image_frame.grid(row=1, column=1, sticky="nsew")

        # Configure the main frame grid to allocate space for the buttons and image frames
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=3)  # Give more weight to the image frame

        # Load the background image and place it in the image frame
        self.background_image = tk.PhotoImage(file="satellite bg.png")
        self.background_label = tk.Label(
            self.image_frame, image=self.background_image, bg="white"
        )
        self.background_label.pack(side="right", fill="both", expand=True)

        self.instruction_label = tk.Label(
            self,
            text="Hover over a button",
            font=("Helvetica", 14),
            bd=1,
            relief="sunken",
            anchor="center",
        )

        # Instruction label should span the entire width and should be at the bottom
        self.instruction_label.grid(
            row=3, column=0, columnspan=2, sticky="ew", padx=0, pady=0
        )

    def on_enter(self, event, message):
        self.instruction_label.config(text=message)

    def on_leave(self, event):
        self.instruction_label.config(text="Hover over a button")

    def go_back(self):
        return

class AdminBasePage(tk.Frame):
    def __init__(self, parent, controller, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)
        self.controller = controller

        # Load images
        self.go_back_img = tk.PhotoImage(file="craft_gui_go_back_button.png")
        self.wifi_img = tk.PhotoImage(file="wifi img.png")

        # Top frame for logo and go back button
        self.top_frame = tk.Frame(self, bg="white")
        self.top_frame.grid(row=0, column=0, sticky="ew", columnspan=2)
        self.top_frame.grid_columnconfigure(1, weight=1)

        # Go back button
        self.go_back_button = tk.Button(
            self.top_frame,
            image=self.go_back_img,
            borderwidth=0,
            highlightthickness=0,
            command=self.go_back,
        )
        self.go_back_button.grid(row=0, column=0, padx=20, pady=10, sticky="w")
        self.go_back_button.image = self.go_back_img  # Keep a reference

        # Logo label
        logo_label = tk.Label(
            self.top_frame, text="C.R.A.F.T", font=("Helvetica", 46), bg="white"
        )
        logo_label.grid(row=0, column=1, padx=20, pady=10, sticky="w")

        # WiFi Label
        self.wifi_label = tk.Label(self.top_frame, image=self.wifi_img, bd=0)
        self.wifi_label.grid(row=0, column=7, padx=10, pady=10, sticky="e")

        # Welcome label
        self.welcome_label = tk.Label(
            self.top_frame,
            text="Welcome (first name, last name)",
            font=("Helvetica 16 underline"),
            bg="white",
        )
        self.welcome_label.grid(row=0, column=6, padx=10, pady=10, sticky="e")

        # Configure the main frame grid to allocate space for the treeview and registration frames
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(
            1, weight=3
        )  # Give more weight to the registration frame

        self.instruction_label = tk.Label(
            self,
            text="Hover over a button",
            font=("Helvetica", 14),
            bd=1,
            relief="sunken",
            anchor="center",
        )
        # Instruction label should span the entire width and should be at the bottom
        self.instruction_label.grid(
            row=3, column=0, columnspan=2, sticky="ew", padx=0, pady=0
        )

        # Setup GUI components
        self.setup_gui()

    def setup_gui(self):
        self.grid_rowconfigure(1, weight=1)  # Treeview
        self.grid_rowconfigure(2, weight=0)  # Buttons should not expand much

        # Frames
        self.treeview_frame = tk.Frame(self, bg="white")
        self.treeview_frame.grid(row=1, column=0, sticky="nsew")
        self.buttons_frame = tk.Frame(self, bg="white")
        self.buttons_frame.grid(row=2, column=0, sticky="nsew")
        self.registration_frame = tk.Frame(self, bg="white")
        self.registration_frame.grid(row=1, column=1, sticky="nsew")

        # Treeview setup
        self.setup_treeview(self.treeview_frame)

    def setup_treeview(self, treeview_frame):
        style = ttk.Style(self.master)
        style.theme_use("clam")
        style.configure(
            "Treeview",
            background="gray25",
            foreground="white",
            rowheight=45,
            fieldbackground="gray25",
        )
        style.map("Treeview", background=[("selected", "orange")])

        self.my_tree = ttk.Treeview(treeview_frame, height=17)
        self.my_tree.grid(row=0, column=0, sticky="nsew", padx=0, pady=20)
        self.my_tree_scroll = tk.Scrollbar(treeview_frame)
        self.my_tree_scroll.grid(row=0, column=1, sticky="ns")

        # Configure the scrollbar to work with the treeview
        self.my_tree.config(yscrollcommand=self.my_tree_scroll.set)
        self.my_tree_scroll.config(command=self.my_tree.yview)


    def process_removal_request(self):
        raise NotImplementedError("This method should be overridden in derived classes")

    def on_enter(self, event, message):
        self.instruction_label.config(text=message)

    def on_leave(self, event):
        self.instruction_label.config(text="Hover over a button")

    def go_back(self):
        raise NotImplementedError("This method should be overridden in derived classes")

class Login(BasePage):
    def __init__(self, parent, controller):
        super().__init__(parent, controller)
        self.controller = controller
        self.otp = True

        self.go_back_button.destroy()
        self.welcome_label.destroy()

        self.offline_img = tk.PhotoImage(file="CRAFT_GUI_offline_01.drawio.png")

        self.wifi_label.configure(image=self.offline_img, bd=0)
        self.wifi_label.grid(row=0, column=4, padx=2, pady=2, sticky="e")

        # Frame for the buttons
        entries_frame = tk.Frame(self, bg="white")
        entries_frame.grid(row=1, column=0, sticky="nsew", padx=50)

        # Configure the grid for the buttons frame
        entries_frame.grid_columnconfigure(0, weight=1)
        entries_frame.grid_columnconfigure(1, weight=1)

        for i in range(12):  # Assuming 4 rows for the buttons and label
            entries_frame.grid_rowconfigure(i, weight=1)

        # Grid configuration
        self.grid_columnconfigure((0, 1), weight=1)
        self.grid_rowconfigure((0, 1, 2), weight=1)

        # Transparent email entry
        self.email_entry = customtkinter.CTkEntry(
            entries_frame,
            placeholder_text="Enter your email",
            width=300,
            height=50,
            fg_color="gray16",
            border_color="black",
            justify="center",
            corner_radius=8,
            border_width=1,
            text_color="white",
            font=("Helvetica", 16),
        )
        self.email_entry.grid(row=6, column=0, padx=10, sticky="ew")

        self.otp_entry = customtkinter.CTkEntry(
            entries_frame,
            placeholder_text="Enter OTP",
            text_color="white",
            width=300,
            height=50,
            border_color="black",
            fg_color="gray16",
            justify="center",
            corner_radius=8,
            border_width=1,
            font=("Helvetica", 16),
        )
        self.otp_entry.grid(row=7, column=0, padx=10, sticky="ew")

        self.password_entry = customtkinter.CTkEntry(
            entries_frame,
            placeholder_text="Password",
            text_color=("white"),
            width=300,
            height=50,
            border_color="black",
            fg_color="gray16",
            justify="center",
            corner_radius=8,
            border_width=1,
            font=("Helvetica", 16),
        )
        self.password_entry.grid(row=8, column=0, padx=10, sticky="ew")

        self.login_button = customtkinter.CTkButton(
            entries_frame,
            text="Login",
            font=("Helvetica", 20),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            anchor="center",
            command=self.login,
        )
        self.login_button.grid(row=9, column=0)

        self.use_offline_button = customtkinter.CTkButton(
            self.top_frame,
            text="Use offline",
            height=40,
            width=10,
            font=("Helvetica", 12),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            anchor="center",
            command=self.use_offline,
        )
        self.use_offline_button.grid(row=0, column=1, sticky="e")

        self.select_auth_method_button = customtkinter.CTkButton(
            self.top_frame,
            text="use backup password",
            height=40,
            width=10,
            font=("Helvetica", 12),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            anchor="center",
            command=self.change_auth_method,
        )
        self.select_auth_method_button.grid(row=0, column=2, sticky="e")

        self.register_user_button = customtkinter.CTkButton(
            self.top_frame,
            text="Register user",
            height=40,
            width=10,
            font=("Helvetica", 12),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            anchor="center",
            command=self.register,
        )
        self.register_user_button.grid(row=0, column=3, sticky="e")

    def login(self):
        email = self.email_entry.get()
        backup_password = self.password_entry.get()
        otp = self.otp_entry.get()

        if self.otp is True:
            data = {"email": email, "otp": otp}
            self.controller.set_user_email(email)
            response = requests.post("http://127.0.0.1:8080/login_otp", json=data)

        if self.otp is False:
            data = {"email": email, "password": backup_password}
            self.controller.set_user_email(email)
            response = requests.post("http://127.0.0.1:8080/login_password", json=data)

        result = response.json()
        print(result)  # Print the server response for debugging
        if "success" in result and result["success"]:
            user_type = result.get("user_type")
            if user_type == "Admin":
                self.controller.set_user_email(email)
                self.controller.show_frame(AdminEntry)
            else:
                self.controller.set_user_email(email)
                self.controller.show_frame(WelcomePage)
        else:
            print(result.get("message", "Unknown error"))
            print("Could not login: Invalid email adress or password")

    def register(self):
        self.controller.show_frame(RegisterUser)

    def change_auth_method(self):
        if self.otp is True:  # change to backup
            self.password_entry.configure(state="normal")
            self.otp_entry.delete(0, "end")
            self.otp_entry._activate_placeholder()
            self.otp_entry.configure(state="disabled")

            self.select_auth_method_button.configure(text="Swap to OTP")
            self.otp = False
            return

        if self.otp is False:
            self.otp_entry.configure(state="normal")
            self.password_entry.delete(0, "end")
            self.password_entry._activate_placeholder()
            self.password_entry.configure(state="disabled")
            self.select_auth_method_button.configure(text="Swap to password")
            self.otp = True
            return

    def use_offline(self):
        self.controller.show_frame(ViewOwnSatellites)

class RegisterUser(BasePage):
    def __init__(self, parent, controller):
        super().__init__(parent, controller)
        self.controller = controller
        self.otp = True

        self.go_back_button.destroy()
        self.welcome_label.destroy()
        self.offline_img = tk.PhotoImage(file="CRAFT_GUI_offline_01.drawio.png")

        self.wifi_label.configure(image=self.offline_img, bd=0)
        self.wifi_label.grid(row=0, column=4, padx=2, pady=2, sticky="e")

        # Frame for the buttons
        entries_frame = tk.Frame(self, bg="white")
        entries_frame.grid(row=1, column=0, sticky="nsew", padx=50)

        # Configure the grid for the buttons frame
        entries_frame.grid_columnconfigure(0, weight=1)
        entries_frame.grid_columnconfigure(1, weight=1)

        for i in range(12):  # Assuming 4 rows for the buttons and label
            entries_frame.grid_rowconfigure(i, weight=1)

        # Grid configuration
        self.grid_columnconfigure((0, 1), weight=1)
        self.grid_rowconfigure((0, 1, 2), weight=1)

        # Transparent email entry
        self.email_entry = customtkinter.CTkEntry(
            entries_frame,
            placeholder_text="Enter your email",
            width=300,
            height=50,
            fg_color="gray16",
            border_color="black",
            justify="center",
            corner_radius=8,
            border_width=1,
            text_color="white",
            font=("Helvetica", 16),
        )
        self.email_entry.grid(row=6, column=0, padx=10, sticky="ew")

        self.firstname_entry = customtkinter.CTkEntry(
            entries_frame,
            placeholder_text="Enter firstname",
            text_color="white",
            width=300,
            height=50,
            border_color="black",
            fg_color="gray16",
            justify="center",
            corner_radius=8,
            border_width=1,
            font=("Helvetica", 16),
        )
        self.firstname_entry.grid(row=7, column=0, padx=10, sticky="ew")

        self.lastname_entry = customtkinter.CTkEntry(
            entries_frame,
            placeholder_text="Enter lastname",
            text_color="white",
            width=300,
            height=50,
            border_color="black",
            fg_color="gray16",
            justify="center",
            corner_radius=8,
            border_width=1,
            font=("Helvetica", 16),
        )
        self.lastname_entry.grid(row=8, column=0, padx=10, sticky="ew")

        self.password_entry = customtkinter.CTkEntry(
            entries_frame,
            placeholder_text="Password",
            text_color=("white"),
            width=300,
            height=50,
            border_color="black",
            fg_color="gray16",
            justify="center",
            corner_radius=8,
            border_width=1,
            font=("Helvetica", 16),
        )
        self.password_entry.grid(row=9, column=0, padx=10, sticky="ew")

        self.register_button = customtkinter.CTkButton(
            entries_frame,
            text="Register",
            font=("Helvetica", 20),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            anchor="center",
            command=self.register,
        )
        self.register_button.grid(row=10, column=0)

        self.use_offline_button = customtkinter.CTkButton(
            self.top_frame,
            text="Use offline",
            height=40,
            width=10,
            font=("Helvetica", 12),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            anchor="center",
            command=self.use_offline,
        )
        self.use_offline_button.grid(row=0, column=1, sticky="e")

        self.login_button = customtkinter.CTkButton(
            self.top_frame,
            text="Login",
            height=40,
            width=10,
            font=("Helvetica", 12),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            anchor="center",
            command=self.go_back,
        )
        self.login_button.grid(row=0, column=3, sticky="e")

    def register(self):
        email = self.email_entry.get()
        data = {
            "email": email,
            "firstname": self.firstname_entry.get(),
            "lastname": self.lastname_entry.get(),
            # "phone_no": self.phone_no_entry.get(),
            "user_type": "Student",
            "backup_password": self.password_entry.get(),
        }

        response = requests.post(
            "http://127.0.0.1:8080/register_user", json=data
        )  # contacts backend server
        response.raise_for_status()  # Will raise an HTTPError for bad requests (400 or 500)
        result = response.json()
        print(result)

        if "success" in result and result["success"]:
            qr_url = result.get("qr_url")
            self.make_qr_code(qr_url, email)

    def make_qr_code(self, qr_url, email):
        qr_code = qrcode.make(qr_url)
        self.show_qr_code(email, qr_code)

    def show_qr_code(self, email, qr_code):
        qr_file = "qrcode_%s.png" % email
        qr_code.save(qr_file)

        # Now load this image with PIL and convert it to a Tkinter compatible image
        pil_image = Image.open(qr_file)
        tk_image = ImageTk.PhotoImage(pil_image)

        # Use tk_image in your Tkinter label
        self.background_label.configure(image=tk_image)
        self.background_label.image = tk_image  # Keep a reference!
        self.background_label.configure(image=qr_code)

    def go_back(self):
        print("Go back button has been pressed")
        self.controller.show_frame(Login)

    def use_offline(self):
        self.controller.show_frame(ViewOwnSatellites)

class WelcomePage(BasePage):
    def __init__(self, parent, controller):
        super().__init__(parent, controller)
        self.controller = controller

        # Frame for the buttons
        buttons_frame = tk.Frame(
            self, bg="white"
        )  # Assuming 'white' is the desired background color
        buttons_frame.grid(row=1, column=0, sticky="nsew")

        # Configure the grid for the buttons frame
        buttons_frame.grid_columnconfigure(0, weight=1)
        buttons_frame.grid_columnconfigure(1, weight=1)

        for i in range(4):  # Assuming 4 rows for the buttons and label
            buttons_frame.grid_rowconfigure(i, weight=1)

        # Grid configuration
        self.grid_columnconfigure((0, 1), weight=1)
        self.grid_rowconfigure((0, 1, 2), weight=1)

        self.view_own_button = customtkinter.CTkButton(
            buttons_frame,
            text="View own satellites",
            font=("Helvetica", 20),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            anchor="center",
            command=self.view_own,
        )

        self.view_all_button = customtkinter.CTkButton(
            buttons_frame,
            text="View all satellites",
            height=80,
            width=30,
            font=("Helvetica", 20),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            anchor="center",
            command=self.view_all,
        )

        self.faq_button = customtkinter.CTkButton(
            buttons_frame,
            text="FAQ",
            height=80,
            width=30,
            font=("Helvetica", 20),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            anchor="center",
            command=self.view_all,
        )

        self.about_us_button = customtkinter.CTkButton(
            buttons_frame,
            text="About us",
            height=80,
            width=30,
            font=("Helvetica", 20),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            anchor="center",
            command=self.view_all,
        )

        button_width = 200  # Set the width you want for your buttons
        button_height = 50  # Set the height you want for your buttons

        # Update the button configurations
        self.view_own_button.configure(width=button_width, height=button_height)
        self.view_all_button.configure(width=button_width, height=button_height)
        self.faq_button.configure(width=button_width, height=button_height)
        self.about_us_button.configure(width=button_width, height=button_height)

        self.view_own_button.grid(row=1, column=0, padx=20, pady=20, sticky="nsew")
        self.view_all_button.grid(row=1, column=1, padx=20, pady=20, sticky="nsew")
        self.faq_button.grid(row=2, column=0, padx=20, pady=20, sticky="nsew")
        self.about_us_button.grid(row=2, column=1, padx=20, pady=20, sticky="nsew")

        self.view_own_button.bind(
            "<Enter>",
            lambda event, msg="View own satellites": self.on_enter(event, msg),
        )
        self.view_own_button.bind("<Leave>", self.on_leave)

        self.view_all_button.bind(
            "<Enter>",
            lambda event, msg="View all satellites": self.on_enter(event, msg),
        )
        self.view_all_button.bind("<Leave>", self.on_leave)

    def go_back(self):
        print("Go back button has been pressed")
        self.controller.show_frame(Login)

    def view_own(self):
        self.controller.show_frame(ViewOwnSatellites)

    def view_all(self):
        print("Option 2 chosen")

class ViewOwnSatellites(BasePage):
    def __init__(self, parent, controller):
        super().__init__(parent, controller)
        self.controller = controller

        # Frame for the buttons
        buttons_frame = tk.Frame(self, bg="white")
        buttons_frame.grid(row=1, column=0, sticky="nsew")

        # Configure the grid for the buttons frame
        buttons_frame.grid_columnconfigure(0, weight=1)
        buttons_frame.grid_columnconfigure(1, weight=1)

        for i in range(4):  # Assuming 4 rows for the buttons and label
            buttons_frame.grid_rowconfigure(i, weight=1)

        # Grid configuration
        self.grid_columnconfigure((0, 1), weight=1)
        self.grid_rowconfigure((0, 1, 2), weight=1)

        self.view_real_time_button = customtkinter.CTkButton(
            buttons_frame,
            text="View real-time data",
            height=80,
            width=30,
            font=("Helvetica", 20),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            anchor="center",
            command=self.view_real_time,
        )

        self.log_history_button = customtkinter.CTkButton(
            buttons_frame,
            text="Access log history",
            height=80,
            width=30,
            font=("Helvetica", 20),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            anchor="center",
            command=self.personal_log_history,
        )

        button_width = 200  # Set the width you want for your buttons
        button_height = 50  # Set the height you want for your buttons

        # Update the button configurations
        self.view_real_time_button.configure(width=button_width, height=button_height)
        self.log_history_button.configure(width=button_width, height=button_height)

        self.view_real_time_button.grid(
            row=1, column=0, padx=20, pady=20, sticky="nsew"
        )
        self.log_history_button.grid(row=1, column=1, padx=20, pady=20, sticky="nsew")

        self.view_real_time_button.bind(
            "<Enter>",
            lambda event, msg="View satellite data in real-time": self.on_enter(
                event, msg
            ),
        )
        self.view_real_time_button.bind("<Leave>", self.on_leave)

        self.log_history_button.bind(
            "<Enter>",
            lambda event, msg="Access log history": self.on_enter(event, msg),
        )
        self.log_history_button.bind("<Leave>", self.on_leave)

    def view_real_time(self):
        self.controller.show_frame(ConfigurePlot)

    def personal_log_history(self):
        pass
        self.controller.show_frame(SaveHistory)

    def go_back(self):
        if PlotInterface not in self.controller.frames:
            self.controller.show_frame(AdminEntry)
        else:
            self.controller.show_frame(WelcomePage)


class SaveHistory(BasePage):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller

        self.db = None
        self.my_collection = None
        self.connected = False

        self.output_mongodb = ""

        # Load images
        self.go_back_img = tk.PhotoImage(file="craft_gui_go_back_button.png")

        # Top frame as usual but with specified height
        top_frame = tk.Frame(self, bg="white", height=100)  # Adjust height as needed
        top_frame.pack(fill="x", expand=False)  # Changed fill to "x" to expand horizontally

        self.dropdown_frame = tk.Frame(self)
        self.dropdown_frame.pack()

        # Go back button
        self.go_back_button = tk.Button(
            top_frame,
            image=self.go_back_img,
            borderwidth=0,
            highlightthickness=0,
            command=self.go_back,
        )
        # The button is packed first so it will still be on the left
        self.go_back_button.pack(side="left", padx=20, pady=10)
        self.go_back_button.image = self.go_back_img  # Keep a reference

        # Logo label
        logo_label = tk.Label(top_frame, text="SaveHistory", font=("Helvetica", 46), bg="white")
        # Use place method for center alignment in parent frame
        logo_label.place(anchor='c', relx=.5, rely=.5)

        # Define instance variables that will be used in refresh as well
        self.buttons = {}

        # Creation of container frame and self initializing
        container = tk.Frame(self, bg="white", height=100)
        container.pack(fill=tk.X)
        self.canvas = tk.Canvas(container, bg="grey80")
        self.buttons_frame = tk.Frame(self.canvas, bg="grey80")

        scrollbar = tk.Scrollbar(container, orient="horizontal", command=self.canvas.xview)
        scrollbar.pack(side="bottom", fill="x")
        self.canvas.configure(xscrollcommand=scrollbar.set)

        save_button = customtkinter.CTkButton(
            self,
            text="Save to disk",
            font=("Helvetica", 24),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            height=45,
            width=225,
            command=lambda: [
                self.controller.frames[PlotInterface].FileManagement.export_from_mongo_db(self.selected_columns[0]) if
                PlotInterface in self.controller.frames and self.selected_columns else self.export_from_mongo_db(self.selected_columns[0]), self.refresh()]
        )
        save_button.pack(pady=10)

        delete_button = customtkinter.CTkButton(
            self,
            text="Delete",
            font=("Helvetica", 24),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            height=45,
            width=225,
            command=lambda: [
                self.controller.frames[PlotInterface].FileManagement.delete_from_mongo_db(self.selected_columns[0]) if
                PlotInterface in self.controller.frames and self.selected_columns else self.delete_from_mongo_db(self.selected_columns[0]), self.refresh()]
        )
        delete_button.pack(pady=10)

        refresh_button = customtkinter.CTkButton(
            self,
            text="Refresh",
            font=("Helvetica", 24),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            height=45,
            width=225,
            command=lambda: self.refresh()
        )
        refresh_button.pack(pady=10)

        self.canvas.pack(side="top", fill="both", expand=True)

        self.status_label = tk.Label(self.dropdown_frame, text='', fg='green')
        self.status_label.pack(side="left", padx=10, pady=10)

        self.refresh()

    def refresh(self):
        print("refresh")
        self.buttons_frame.destroy()  # Destroy the previous frame
        self.buttons_frame = tk.Frame(self.canvas, bg="grey80")  # Create a new one in the same canvas
        self.canvas.create_window((0, 0), window=self.buttons_frame, anchor='nw')  # Add the frame back in to the canvas
        self.buttons = {}  # clear the old buttons

        if PlotInterface not in self.controller.frames:
            self.save_instances = self.get_all_saved_instances()
            print("PlotInterface is not initialized")
        else:
            self.save_instances = self.controller.frames[PlotInterface].FileManagement.get_all_saved_instances()

        if self.save_instances is None:
            print("refresh return")
            return

        # Create buttons based on save_instances
        for i, history in enumerate(reversed(self.save_instances)):
            filename = history.get("Filename", "")
            start_date = history.get("Start Date", "")
            end_date = history.get("End Date", "")
            total_elapse = history.get("Total Elapse", "")

            button_text = f"Filename: {filename}\t\tStart Date: {start_date}\n\n"
            button_text += f"End Date: {end_date}\t\t"
            button_text += f"Total Elapse: {total_elapse}"

            button = customtkinter.CTkButton(
                self.buttons_frame,
                text=button_text,
                font=("Helvetica", 36),
                fg_color="orange",
                text_color="black",
                corner_radius=10,
                border_width=3,
                border_color="black",
                hover_color="DarkOrange2",
                anchor="center",
                command=self.get_button_press_command(filename)
            )
            button.grid(row=0, column=i, padx=20)
            self.buttons[filename] = button

        self.buttons_frame.update_idletasks()
        self.canvas.configure(scrollregion=self.canvas.bbox('all'))
        self.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))

    def get_button_press_command(self, filename):
        # self.refresh()
        return lambda: self.button_press(filename)

    def button_press(self, filename):
        for btn in self.buttons.values():
            btn.configure(fg_color="orange")
        button = self.buttons[filename]
        button.configure(fg_color="green")
        self.selected_columns = [filename]

    def show_group_dropdown(self):
        group_names = ["no_group"]
        group_names.extend(self.fetch_group_names())  # Fetch all group names

        print(group_names)

        # If request fails to fetch group names, group_names will be an empty list.
        if not group_names:
            print("Failed to fetch group names...")
            return

        # create label Choose group to view save log
        prompt_label = tk.Label(self.dropdown_frame, text="Choose group to view save log: ")
        prompt_label.pack(side="left")

        self.group_var = tk.StringVar()  # creating tk string variable for storage and tracing

        self.group_dropdown = ttk.Combobox(self.dropdown_frame, textvariable=self.group_var)  # creating combobox
        self.group_dropdown['values'] = group_names  # setting values
        self.group_dropdown.pack(side="left", padx=10, pady=10)  # arrange it using pack

        self.ok_button = tk.Button(self.dropdown_frame, text="Ok", command=self.ok_pressed)  # creating Ok button
        self.ok_button.pack(side="left", padx=10, pady=10)  # arrange it using pack

        # label for showing the selected group
        self.status_label = tk.Label(self.dropdown_frame, text="")
        self.status_label.pack(side="left")

    def ok_pressed(self):  # new method to handle clicking of OK button
        group = self.group_var.get()
        self.status_label.config(text=f"Viewing {group}")  # updates text of status label
        self.after(2000, lambda: self.status_label.config(text=""))  # after 2000 ms (2 sec), clear label
        self.connect_to_mongodb(group)
        self.refresh()

    def connect_to_mongodb(self, group_name):
        try:
            print(group_name)
            client = pymongo.MongoClient(
                mongodb_credentials,
                serverSelectionTimeoutMS=1000)
            client.server_info()  # This line will raise an error if the connection failed
            self.db = client.sensor_data
            self.my_collection = self.db[group_name]
            self.connected = True

        except pymongo.errors.ServerSelectionTimeoutError as err:
            print("Unable to connect to MongoDB server")

    def save_mongodb_dialog(self):
        self.output_mongodb = filedialog.asksaveasfilename(defaultextension=".csv",
                                                        filetypes=[("CSV files", "*.csv")])
        if self.output_mongodb:
            print("output chosen for mongodb database.")
        else:
            print("File merging cancelled: no file path chosen.")

    def export_from_mongo_db(self, filename):
        self.output_mongodb = ''
        print(filename)
        self.save_mongodb_dialog()
        if self.output_mongodb == '':
            return

        name_and_date_doc = self.my_collection.find_one({"Filename": filename})

        start_date = name_and_date_doc["Start Date"]
        end_date = name_and_date_doc["End Date"]

        between_data = list(self.my_collection.find({"Date Time": {"$gte": start_date, "$lte": end_date}}))

        if not between_data:
            print("No data found for")
            return "No documents between the two instances found."

        df_fde = pd.DataFrame([name_and_date_doc]).drop("_id", axis=1)
        df_fde["Start Date"] = df_fde["Start Date"].dt.strftime("%Y.%m.%d")
        df_fde["End Date"] = df_fde["End Date"].dt.strftime("%Y.%m.%d")

        df = pd.DataFrame(between_data).drop("_id", axis=1)
        df["Date Time"] = df["Date Time"].dt.strftime("%H:%M:%S")

        df = pd.concat([df_fde, df], axis=1)
        df.to_csv(self.output_mongodb, sep=';', index=False)

        return f"Export to '{self.output_mongodb}' completed."

    def delete_from_mongo_db(self, filename=None):
        print("Deleting data from MongoDB...")
        if filename:
            name_and_date_doc = self.my_collection.find_one({"Filename": filename})

            if name_and_date_doc is None:
                print(f"No documents found with filename {filename}.")
                return

            start_date = name_and_date_doc["Start Date"]
            end_date = name_and_date_doc["End Date"]

            # Delete the document matching the filename
            if self.my_collection is not None:
                self.my_collection.delete_one({"Filename": filename})
        else:
            start_date = "some start date"    # use actual start date
            end_date = datetime.now()

        if self.my_collection is not None:
            res = self.my_collection.delete_many({"Date Time": {"$gte": start_date, "$lte": end_date}})
            print(f"Deleted {res.deleted_count} documents")
        else:
            print("Cannot delete entries from None collection.")

    def get_all_saved_instances(self):
        # Check if connection to MongoDB has been established
        if self.my_collection is None:
            print('my_collection not initialized yet')
            return None

        try:
            # Query the collection and transform it into a list
            docs = list(
                self.my_collection.find({},
                                        {"_id": 0, "Filename": 1, "Start Date": 1, "End Date": 1, "Total Elapse": 1})
                .sort("Start Date", 1))

            # Remove any empty dictionaries from the list before returning
            docs = [doc for doc in docs if doc]

            # If the resulting list is empty, return None
            if not docs:
                return None
            else:
                return docs

        except pymongo.errors.PyMongoError as e:
            print(f"Unable to retrieve documents: {e}")
            return None

    def fetch_group_names(self):
        try:
            response = requests.get("http://127.0.0.1:8080/fetch_all_group_names")
            response.raise_for_status()  # Raise HTTPError for bad response status codes
            data = response.json()
            if data['success']:
                return data['group_names']

        except requests.RequestException as e:
            print(f"Error fetching group names: {e}")

        return []

    def go_back(self):
        if PlotInterface not in self.controller.frames:
            self.controller.show_frame(AdminEntry)
        else:
            self.controller.show_frame(ViewOwnSatellites)


class ConfigurePlot(BasePage):
    def __init__(self, parent, controller):
        super().__init__(parent, controller)
        self.controller = controller
        self.sensor_buttons = {}
        self.persistent_selections = {}  # Store selections persistently
        self.sensor_buttons = {}
        self.image_frame.destroy()

        # Create the canvas and the scrollbar
        self.canvas = tk.Canvas(
            self, bg="white", highlightthickness=0
        )  # Set the thickness of the border

        self.scrollbar = tk.Scrollbar(
            self, orient="vertical", command=self.canvas.yview
        )
        self.canvas.configure(yscrollcommand=self.scrollbar.set)

        # Adjust the grid configuration to respect base layout
        self.grid_rowconfigure(1, weight=1)  # Allow the main content area to expand
        self.grid_rowconfigure(2, minsize=20)  # Minimal space before the instruction label

        # Add the canvas and scrollbar to the window
        self.canvas.grid(row=1, column=0, sticky="nsew", columnspan=1)  # Span only the first column for the canvas
        self.scrollbar.grid(row=1, column=1, sticky="ns")

        # Configure columns to manage space correctly
        self.grid_columnconfigure(0, weight=1)  # Main content should expand
        self.grid_columnconfigure(1, weight=0)  # Minimal weight to scrollbar

        # Frame for the buttons inside the canvas
        self.buttons_frame = tk.Frame(self.canvas, bg="white")
        self.canvas_frame_id = self.canvas.create_window((0, 0), window=self.buttons_frame, anchor="nw")
        self.buttons_frame.bind("<Configure>", self.on_frame_configure)
        self.buttons_frame.grid(row=1, column=0, sticky="nsew", padx=20, pady=200)

        # Go to Plot Interface Button
        plot_interface_button = customtkinter.CTkButton(
            self,
            text='Go to plot interface',
            height=50,
            width=200,
            font=("Helvetica", 20),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            anchor="center",
            command=self.accept_plot_interface,
        )
        plot_interface_button.grid(row=2, column=0, padx=20, pady=20)  # place it above the instruction label

        self.create_sensor_buttons()
        self.sensors_to_plot = list(())

        # Bind the resize event to a handler
        self.bind("<Configure>", self.on_resize)

    def on_resize(self, event):
        # This method will be called whenever the window is resized
        self.create_sensor_buttons()

    def on_frame_configure(self, event):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def create_sensor_buttons(self):
        sensor_data = self.retrieve_sensors()

        # Clear existing buttons if they exist
        for button in self.sensor_buttons.values():
            button.destroy()

        # Define button width and padding
        button_width = 100
        button_padding = 10
        total_button_width = button_width + 2 * button_padding

        # Get the width of the frame where buttons are placed
        frame_width = (self.buttons_frame.winfo_width())  # You may need to update this on window resize as well

        # If width is still not computed correctly, fallback to a default width (e.g., typical screen width)
        if frame_width < 200:  # 200 is an arbitrary threshold for a reasonable width
            frame_width = (self.winfo_screenwidth() * 0.6)  # Use 60% of screen width as fallback

        # Calculate the number of columns that can fit in the available space
        num_columns = max(1, frame_width // total_button_width)

        col = 0
        row = 0

        for sensor in sensor_data:
            sensor_id = sensor["id"]
            sensor_name = sensor["name"]

            button = customtkinter.CTkButton(
                self.buttons_frame,
                text=sensor_name,
                height=80,
                width=100,
                font=("Helvetica", 20),
                fg_color="gray16",  # Initial background color
                text_color="gray93",
                corner_radius=8,
                border_width=3,
                border_color="black",
                hover_color="DarkOrange2",
                anchor="center",
                command=lambda id=sensor_id, name=sensor_name: self.on_sensor_click(
                    id, name
                ),
            )
            button.pressed = False
            self.sensor_buttons[sensor_id] = button

            button.grid(row=row, column=col, padx=button_padding, pady=button_padding)

            col += 1
            if col >= num_columns:
                col = 0
                row += 1

        self.update_scrollregion()


    def accept_plot_interface(self):
        self.controller.set_config_sensors(self.sensors_to_plot)
        self.controller.show_frame(PlotInterface)

    def update_scrollregion(self):
        # Update the scroll region to encompass the new size of the buttons frame
        self.canvas.configure(scrollregion=self.canvas.bbox(self.canvas_frame_id))

    def on_frame_configure(self, event=None):
        # Reset the scroll region to encompass the inner frame
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def retrieve_sensors(self):
        try:
            response = requests.get("http://127.0.0.1:8080/fetch_sensors")
            response.raise_for_status()  # Raise HTTPError for bad response status codes
            return response.json()

        except requests.RequestException as e:
            print(f"Error fetching sensor names: {e}")
            return []

    def on_sensor_click(self, sensor_id, sensor_name):
        print(f"Clicked on sensor with ID: {sensor_id} and name: {sensor_name}")
        self.show_sub_sensors(sensor_id, sensor_name)

        for button in self.winfo_children():
            if (
                    isinstance(button, customtkinter.CTkButton)
                    and button.cget("text") == sensor_name
            ):
                print(button.pressed)
                if button.pressed == False:
                    button.configure(fg_color="green")  # Change color when clicked
                    button.pressed = True
                else:
                    button.configure(fg_color="grey")  # Revert color to normal
                    button.pressed = False
                break  # Once the button is found and updated, exit the loop
            else:
                print(
                    f"No matching button for sensor name: {sensor_name} (in this loop iteration)"
                )

    def show_sub_sensors(self, sensor_module_id, sensor_module_name):
        # Retrieve sub sensors for the given sensor module
        sub_sensors = self.retrieve_sub_sensors(sensor_module_id)

        # Create a top-level window
        popup = tk.Toplevel(self)
        popup.title(f"Sub Sensors for {sensor_module_id}")
        popup.geometry("")  # Width x Height

        # Use a frame to contain the checklist
        checklist_frame = tk.Frame(popup)
        checklist_frame.pack(padx=10, pady=10, fill="both", expand=True)

        # Keep a dictionary to keep track of the Checkbuttons and their respective variables
        self.check_vars = {}

        for sub_sensor in sub_sensors:
            sub_sensor_id = sub_sensor["id"]
            sub_sensor_name = sub_sensor["type"]
            unit = sub_sensor["measuring_unit"]
            # alt_unit = sub_sensor['alt_measuring_unit']

            # Ensure default values are correctly managed
            stored_values = self.persistent_selections.get(sub_sensor_id, {'checked': False, 'prefix': None})
            check_var = tk.BooleanVar(value=stored_values['checked'])
            selected_prefix = tk.StringVar(value=stored_values['prefix'] if stored_values['prefix'] is not None else "")

            check_button = tk.Checkbutton(
                checklist_frame, text=sub_sensor_name, variable=check_var
            )
            check_button.pack(anchor="w", pady=2)

            prefix_frame = tk.Frame(checklist_frame)  # Frame to hold the radiobuttons horizontally
            prefix_frame.pack(side="top", fill="x", expand=True)

            prefixes = self.get_prefixes()
            for prefix in prefixes:
                prefix_button = tk.Radiobutton(prefix_frame, text=prefix, variable=selected_prefix, value=prefix)
                prefix_button.pack(side="left")

            self.check_vars[sub_sensor_id] = (
                {  # Store the variables associated with the checkbutton
                    "check_var": check_var,
                    "id": sub_sensor_id,
                    "name": sub_sensor_name,
                    "prefix": selected_prefix,
                    "unit": unit,
                }
            )
        # self.check_vars[sub_sensor_name] = check_var
        # Add a button to process the selected sub-sensors

        # Update persistent selections when changes occur
        check_var.trace_add("write",
                            lambda *args, id=sub_sensor_id, var=check_var: self.update_selections(id, var, None))
        selected_prefix.trace_add("write", lambda *args, id=sub_sensor_id, var=None,
                                                  prefix=selected_prefix.get(): self.update_selections(id, var, prefix))

        submit_button = tk.Button(
            checklist_frame,
            text="Submit",
            command=lambda: self.process_selections(popup, sensor_module_name),
        )
        submit_button.pack(pady=10)

    def update_selections(self, sensor_id, check_var, prefix):
        current = self.persistent_selections.get(sensor_id, {})
        if check_var is not None:
            current['checked'] = check_var.get()
        if prefix is not None:
            current['prefix'] = prefix
        self.persistent_selections[sensor_id] = current
        print(f"Updated selections for {sensor_id}: Checked={current['checked']}, Prefix={current['prefix']}")

    def get_prefixes(self):
        prefixes = [
            "G",
            "k",
            "M",
            "mc",
            "m",
            "n",
            "p",
            "T"
        ]
        return prefixes

    def retrieve_sub_sensors(self, sensor_id):
        try:
            response = requests.get(
                f"http://127.0.0.1:8080/fetch_sub_sensors?sensor_id={sensor_id}"
            )
            response.raise_for_status()  # Raise HTTPError for bad response status codes
            sub_sensors = response.json()
            if not sub_sensors:
                print(f"No sub sensors found for sensor ID: {sensor_id}")
            return sub_sensors

        except requests.RequestException as e:
            print(f"Error fetching sub sensor names: {e}")
            return []

    def process_selections(self, popup, sensor_module_name):
        selected_sensors = []

        # Iterate through the check_vars dictionary to access each sub_sensor's details
        for sub_sensor_id, details in self.check_vars.items():
            check_var = details["check_var"]
            if check_var.get():
                prefix_value = details['prefix'].get()
                selected_sensors.append(
                    (details["id"], details["name"], prefix_value, details["unit"])
                )
                print(
                    f"Selected: ID={details['id']}, Name={details['name']}, Prefix={prefix_value}, Unit={details['unit']}"
                )
            else:
                print(f"Not selected: ID={details['id']}, Name={details['name']}")

        self.sensors_to_plot.extend(selected_sensors)
        print(self.sensors_to_plot)

        # # Now, after processing selections, update button colors.
        # # Iterate through all sensor buttons and update the color if selected.
        # for sensor_id, details in self.check_vars.items():
        #     if details["check_var"].get():  # If this sensor's checkbox is checked
        #         # Change the corresponding button's color to green.
        #         self.sensor_buttons[sensor_id].configure(fg_color="green")
        #     else:
        #         # Change it back to the original color if it is not selected.
        #         self.sensor_buttons[sensor_id].configure(fg_color="gray82")

        popup.destroy()

    def go_back(self):
        self.controller.show_frame(ViewOwnSatellites)


class AdminEntry(BasePage):
    def __init__(self, parent, controller):
        super().__init__(parent, controller)
        self.controller = controller

        # Frame for the buttons
        buttons_frame = tk.Frame(self, bg="white")
        buttons_frame.grid(row=1, column=0, sticky="nsew")

        # Configure the grid for the buttons frame
        buttons_frame.grid_columnconfigure(0, weight=1)
        buttons_frame.grid_columnconfigure(1, weight=1)

        for i in range(4):  # Assuming 4 rows for the buttons and label
            buttons_frame.grid_rowconfigure(i, weight=1)

        # Grid configuration
        self.grid_columnconfigure((0, 1), weight=1)
        self.grid_rowconfigure((0, 1, 2), weight=1)

        self.view_groups_button = customtkinter.CTkButton(
            buttons_frame,
            text="View groups",
            font=("Helvetica", 20),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            anchor="center",
            command=self.view_groups,
        )

        self.view_courses_button = customtkinter.CTkButton(
            buttons_frame,
            text="View courses",
            height=80,
            width=30,
            font=("Helvetica", 20),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            anchor="center",
            command=self.view_courses,
        )

        self.view_users_button = customtkinter.CTkButton(
            buttons_frame,
            text="View users",
            height=80,
            width=30,
            font=("Helvetica", 20),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            anchor="center",
            command=self.view_users,
        )

        self.view_logs_button = customtkinter.CTkButton(
            buttons_frame,
            text="View logs",
            height=80,
            width=30,
            font=("Helvetica", 20),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            anchor="center",
            command=self.view_logs
        )

        self.view_sensors_button = customtkinter.CTkButton(
            buttons_frame,
            text="View sensors",
            height=80,
            width=30,
            font=("Helvetica", 20),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            anchor="center",
            command=self.view_sensors,
        )

        self.view_satellites_button = customtkinter.CTkButton(
            buttons_frame,
            text="View satellites",
            height=80,
            width=30,
            font=("Helvetica", 20),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            anchor="center",
            command=self.view_satellites,
        )

        button_width = 200  # Set the width you want for your buttons
        button_height = 50  # Set the height you want for your buttons

        # Update the button configurations
        self.view_groups_button.configure(width=button_width, height=button_height)
        self.view_courses_button.configure(width=button_width, height=button_height)
        self.view_users_button.configure(width=button_width, height=button_height)
        self.view_logs_button.configure(width=button_width, height=button_height)
        self.view_sensors_button.configure(width=button_width, height=button_height)

        self.view_groups_button.grid(row=1, column=0, padx=20, pady=20, sticky="nsew")
        self.view_courses_button.grid(row=1, column=1, padx=20, pady=20, sticky="nsew")
        self.view_users_button.grid(row=2, column=0, padx=20, pady=20, sticky="nsew")
        self.view_logs_button.grid(row=2, column=1, padx=20, pady=20, sticky="nsew")
        self.view_sensors_button.grid(row=3, column=0, padx=20, pady=20, sticky="nsew")
        self.view_satellites_button.grid(
            row=3, column=1, padx=20, pady=20, sticky="nsew"
        )

        self.view_groups_button.bind(
            "<Enter>",
            lambda event, msg="View own satellites": self.on_enter(event, msg),
        )
        self.view_groups_button.bind("<Leave>", self.on_leave)

        self.view_courses_button.bind(
            "<Enter>",
            lambda event, msg="View all satellites": self.on_enter(event, msg),
        )
        self.view_courses_button.bind("<Leave>", self.on_leave)

    def go_back(self):
        self.controller.show_frame(Login)

    def view_courses(self):
        self.controller.show_frame(Courses)

    def view_groups(self):
        self.controller.show_frame(Groups)

    def view_users(self):
        self.controller.show_frame(Users)

    def view_sensors(self):
        self.controller.show_frame(Sensors)

    def view_satellites(self):
        self.controller.show_frame(Satellites)

    def view_logs(self):
        self.controller.show_frame(SaveHistory)
        self.controller.frames[SaveHistory].show_group_dropdown()


class Sensors(AdminBasePage):
    def __init__(self, parent, controller):
        super().__init__(parent, controller)
        self.controller = controller

        self.my_tree["columns"] = ("ID", "Name", "Type", "Producer")

        self.display_sensors()

        self.my_tree.column("#0", width=0)
        self.my_tree.column("ID", anchor="w", width=300, minwidth=25)
        self.my_tree.column("Name", anchor="w", width=300, minwidth=25)
        self.my_tree.column("Type", anchor="w", width=300, minwidth=25)
        self.my_tree.column("Producer", anchor="w", width=300, minwidth=25)

        self.my_tree.heading("#0", text="f", anchor="w")
        self.my_tree.heading("ID", text="ID", anchor="w")
        self.my_tree.heading("Name", text="Name", anchor="w")
        self.my_tree.heading("Type", text="Type/Measuring unit", anchor="w")
        self.my_tree.heading(
            "Producer", text="Producer/Alt. Measuring unit", anchor="w"
        )
        self.my_tree.grid(row=0, column=0, padx=20, pady=20)

        self.setup_registration_area()

    def setup_registration_area(self):

        submit_module_button = customtkinter.CTkButton(
            self.registration_frame,
            font=("Helvetica", 20),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            anchor="center",
            text="Add Sensor",
            command=lambda: self.add_sensor(
                self.module_name_entry.get(), self.module_type_entry.get(), self.producer_entry.get()
            ),
        )

        submit_sub_sensor_button = customtkinter.CTkButton(
            self.registration_frame,
            font=("Helvetica", 20),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            anchor="center",
            text="Add Sub-Sensor",
            command=lambda: self.add_sub_sensor(
                self.module_id_entry.get(),
                self.sub_sensor_type_entry.get(),
                self.measuring_unit_entry.get(),
                self.alt_measuring_unit_entry.get(),
            ),
        )

        module_labels = ["Name", "Type", "Producer"]
        sub_sensor_labels = ["Module ID", "Name", "Measuring Unit", "Alt. Measuring Unit"]

        # SENSOR MODULE
        self.module_name_label = tk.Label(self.registration_frame, text=module_labels[0], bg="white")
        self.module_name_label.grid(row=0, column=0, sticky="w")
        self.module_name_entry = tk.Entry(self.registration_frame, borderwidth=3)
        self.module_name_entry.grid(row=0, column=1, sticky="ew", padx=0, pady=10)

        module_type_label = tk.Label(self.registration_frame, text=module_labels[1], bg="white")
        module_type_label.grid(row=1, column=0, sticky="w")
        self.module_type_entry = tk.Entry(self.registration_frame, borderwidth=3)
        self.module_type_entry.grid(row=1, column=1, sticky="ew", padx=0, pady=10)

        producer_label = tk.Label(self.registration_frame, text=module_labels[2], bg="white")
        producer_label.grid(row=2, column=0, sticky="w")
        self.producer_entry = tk.Entry(self.registration_frame, borderwidth=3)
        self.producer_entry.grid(row=3, column=1, sticky="ew", padx=0, pady=10)

        submit_module_button.grid(row=4, columnspan=2, pady=40)

        # SUB SENSOR
        self.module_id_label = tk.Label(self.registration_frame, text=sub_sensor_labels[0], bg="white")
        self.module_id_label.grid(row=5, column=0, sticky="w")
        self.module_id_entry = tk.Entry(self.registration_frame, borderwidth=3)
        self.module_id_entry.grid(row=5, column=1, sticky="ew", padx=0, pady=10)

        sub_sensor_type_label = tk.Label(self.registration_frame, text=sub_sensor_labels[1], bg="white")
        sub_sensor_type_label.grid(row=6, column=0, sticky="w")
        self.sub_sensor_type_entry = tk.Entry(self.registration_frame, borderwidth=3)
        self.sub_sensor_type_entry.grid(row=6, column=1, sticky="ew", padx=0, pady=10)

        measuring_unit_label = tk.Label(self.registration_frame, text=sub_sensor_labels[2], bg="white")
        measuring_unit_label.grid(row=7, column=0, sticky="w")
        self.measuring_unit_entry = tk.Entry(self.registration_frame, borderwidth=3)
        self.measuring_unit_entry.grid(row=7, column=1, sticky="ew", padx=0, pady=10)

        alt_measuring_unit_label = tk.Label(self.registration_frame, text=sub_sensor_labels[3], bg="white")
        alt_measuring_unit_label.grid(row=8, column=0, sticky="w")
        self.alt_measuring_unit_entry = tk.Entry(self.registration_frame, borderwidth=3)
        self.alt_measuring_unit_entry.grid(row=8, column=1, sticky="ew", padx=0, pady=10)

        submit_sub_sensor_button.grid(row=9, columnspan=2, pady=40)

    def add_sensor(self, name, sensor_type, producer):
        if not name or not sensor_type or not producer:
            messagebox.showerror("Error", "All fields must be filled out")
            return

        data = {"name": name, "type": sensor_type, "producer": producer}
        response = requests.post("http://127.0.0.1:8080/add_sensor", json=data)

        if response.status_code == 200:
            messagebox.showinfo("Success", "Sensor added successfully")

            # empty entry fields
            self.module_name_entry.delete(0, "end")
            self.module_type_entry.delete(0, "end")
            self.producer_entry.delete(0, "end")

            # update sub-sensor list
            self.display_sensors()

        else:
            messagebox.showerror("Error", f"Failed to add sensor: {response.text}")

    def add_sub_sensor(self, module_id, name, measuring_unit, alt_measuring_unit):
        if not name or not module_id:
            messagebox.showerror(
                "Error", "Name and Module ID must be filled out"
            )
            return

        data = {
            "name": name,
            "module_id": module_id,
            "measuring_unit": measuring_unit,
            "alt_measuring_unit": alt_measuring_unit,
        }
        response = requests.post("http://127.0.0.1:8080/add_sub_sensor", json=data)

        if response.status_code == 200:
            messagebox.showinfo("Success", "Sub-sensor added successfully")
            # empty entry fields
            self.sub_sensor_type_entry.delete(0, "end")
            self.module_id_entry.delete(0, "end")
            self.measuring_unit_entry.delete(0, "end")
            self.alt_measuring_unit_entry.delete(0, "end")

            # update sub-sensor list
            self.display_sensors()

        else:
            messagebox.showerror("Error", f"Failed to add sub-sensor: {response.text}")

    def display_sensors(self):
        # Fetch and clear existing items
        for item in self.my_tree.get_children():
            self.my_tree.delete(item)

        # Fetch courses from the backend
        sensors = self.fetch_sensors()

        # Loop over courses and insert them into the treeview
        for sensor in sensors:
            sensor_id = sensor["id"]
            sensor_item = self.my_tree.insert(
                "",
                "end",
                iid=sensor_id,
                values=(sensor_id, sensor["name"], sensor["type"], sensor["producer"]),
            )

            print("sensor_id", sensor_id)
            # Fetch groups for the given course_id
            sub_sensors = self.fetch_sub_sensors(sensor_id)

            print("Sub sensors fetched:", sub_sensors)
            # Loop over the groups and insert them as children of the course
            for sub_sensor in sub_sensors:
                print(
                    type(sub_sensor), sub_sensor
                )  # This will help determine what `group` actually is

                sub_sensor_id = sub_sensor["id"]
                sub_sensor_iid = f"{sensor_id}-{sub_sensor_id}"  # Corrected to create a unique composite identifier¨
                self.my_tree.insert(
                    sensor_item,
                    "end",
                    iid=sub_sensor_iid,
                    values=(
                        sub_sensor["id"],
                        sub_sensor["type"],
                        sub_sensor["measuring_unit"],
                        sub_sensor["alt_measuring_unit"],
                    ),
                )

    def fetch_sensors(self):
        try:
            response = requests.get("http://127.0.0.1:8080/fetch_sensors")
            response.raise_for_status()  # Raise HTTPError for bad response status codes
            return response.json()

        except requests.RequestException as e:
            print(f"Error fetching courses: {e}")
            return []

    def fetch_sub_sensors(self, sensor_id):
        try:
            response = requests.get(
                f"http://127.0.0.1:8080/fetch_sub_sensors?sensor_id={sensor_id}"
            )
            response.raise_for_status()  # Raise HTTPError for bad response status codes
            return response.json()

        except requests.RequestException as e:
            print(f"Error fetching groups: {e}")
            return []

    def delete_from_db(self, primary_key, iid):
        print("delete function called")
        print(iid)

        data = {"id": primary_key}
        # Use the parent method to check if the item is a child
        item_parent = self.my_tree.parent(iid)
        print(item_parent)

        if item_parent:  # If the item has a parent, it's a child entry
            print("deleting child")
            response = requests.post(
                "http://127.0.0.1:8080/delete_sub_sensor", json=data
            )

        else:  # No parent means it's a root entry or parent sensor
            print("deleting parent")
            response = requests.post("http://127.0.0.1:8080/delete_sensor", json=data)
            print(response.status_code)

        if response.status_code == 200:
            return True
        return False

    def go_back(self):
        self.controller.show_frame(AdminEntry)

    def fetch_sensors(self):
        try:
            response = requests.get("http://127.0.0.1:8080/fetch_sensors")
            response.raise_for_status()  # Raise HTTPError for bad response status codes
            return response.json()

        except requests.RequestException as e:
            print(f"Error fetching courses: {e}")
            return []

    def fetch_sub_sensors(self, sensor_id):
        try:
            response = requests.get(
                f"http://127.0.0.1:8080/fetch_sub_sensors?sensor_id={sensor_id}"
            )
            response.raise_for_status()  # Raise HTTPError for bad response status codes
            return response.json()

        except requests.RequestException as e:
            print(f"Error fetching groups: {e}")
            return []

    def delete_from_db(self, primary_key, iid):
        print("delete function called")
        print(iid)

        data = {"id": primary_key}
        # Use the parent method to check if the item is a child
        item_parent = self.my_tree.parent(iid)
        print(item_parent)

        if item_parent:  # If the item has a parent, it's a child entry
            print("deleting child")
            response = requests.post(
                "http://127.0.0.1:8080/delete_sub_sensor", json=data
            )

        else:  # No parent means it's a root entry or parent sensor
            print("deleting parent")
            response = requests.post("http://127.0.0.1:8080/delete_sensor", json=data)
            print(response.status_code)

        if response.status_code == 200:
            return True
        return False

    def go_back(self):
        self.controller.show_frame(AdminEntry)


class Satellites(AdminBasePage):
    def __init__(self, parent, controller):
        super().__init__(parent, controller)
        self.controller = controller
        self.satellite_types = (
            self.fetch_satellite_types()
        )

        self.my_tree["columns"] = ("Name", "Type", "Group ID")
        self.display_satellites()

        self.my_tree.column("#0", width=0)
        self.my_tree.column("Name", anchor="w", width=300, minwidth=25)
        self.my_tree.column("Type", anchor="w", width=300, minwidth=25)
        self.my_tree.column("Group ID", anchor="w", width=300, minwidth=25)

        self.my_tree.heading("#0", text="f", anchor="w")
        self.my_tree.heading("Name", text="Name", anchor="w")
        self.my_tree.heading("Type", text="Type", anchor="w")
        self.my_tree.heading("Group ID", text="Owner (Group ID)", anchor="w")

        self.remove_img = tk.PhotoImage(file="trash_can.drawio.png")
        self.remove_button = tk.Button(
            self.buttons_frame,
            image=self.remove_img,
            width=70,
            height=70,
            borderwidth=0,
            highlightthickness=0,
            command=self.process_removal_request,
        )

        self.remove_button.image = self.remove_img  # Keep a reference to the image
        self.remove_button.pack(side="left", padx=20, pady=5)
        self.setup_registration_area()

    def fetch_satellite_types(self):
        return ["C.R.A.F.T-Sat", "CanSat"]

    def setup_registration_area(self):
        registration_frame = tk.Frame(self, bg="white")
        registration_frame.grid(row=1, column=1, sticky="nsew", padx=20, pady=20)

        # Sensor Registration
        tk.Label(
            registration_frame, text="Register New Satellite", font=("Arial", 12)
        ).grid(row=0, columnspan=2)

        tk.Label(registration_frame, text="Name:").grid(row=6, sticky="e")
        self.name_entry = tk.Entry(registration_frame)
        self.name_entry.grid(row=6, column=1)

        tk.Label(registration_frame, text="Type:").grid(row=7, sticky="e")
        self.sat_type_entry = ttk.Combobox(
            registration_frame, values=self.satellite_types
        )
        self.sat_type_entry.grid(row=7, column=1)

        tk.Label(registration_frame, text="Owner (Group ID):").grid(row=8, sticky="e")
        self.group_id_entry = tk.Entry(registration_frame)
        self.group_id_entry.grid(row=8, column=1)

        submit_button = tk.Button(
            registration_frame,
            text="Add Satellite",
            command=lambda: self.add_satellite(
                self.name_entry.get(),
                self.sat_type_entry.get(),
                self.group_id_entry.get(),
            ),
        )
        submit_button.grid(row=4, columnspan=2, pady=10)

    def add_satellite(self, name, sat_type, group_id):
        if not name or not sat_type or not group_id:
            messagebox.showerror("Error", "All fields must be filled out")
            return

        data = {"name": name, "sat_type": sat_type, "group_id": group_id}
        print(data)
        response = requests.post("http://127.0.0.1:8080/add_satellite", json=data)

        if response.status_code == 200:
            messagebox.showinfo("Success", "Satellite added successfully")

            # empty entry fields
            self.name_entry.delete(0, "end")
            self.sat_type_entry.delete(0, "end")
            self.group_id_entry.delete(0, "end")

            # update sub-sensor list
            self.display_satellites()

        else:
            messagebox.showerror("Error", f"Failed to add satellite: {response.text}")

    def display_satellites(self):
        # Fetch and clear existing items
        for item in self.my_tree.get_children():
            self.my_tree.delete(item)

        # Fetch courses from the backend
        satellites = self.fetch_satellites()

        # Loop over courses and insert them into the treeview
        for satellite in satellites:
            sat_name = satellite["name"]
            self.my_tree.insert(
                "",
                "end",
                iid=sat_name,
                values=(sat_name, satellite["type"], satellite["group_id"]),
            )
            print("sat_name", sat_name)

    def fetch_satellites(self):
        try:
            response = requests.get("http://127.0.0.1:8080/fetch_all_satellites")
            response.raise_for_status()  # Raise HTTPError for bad response status codes
            return response.json()

        except requests.RequestException as e:
            print(f"Error fetching courses: {e}")
            return []

    def process_removal_request(self):
        selected = self.my_tree.selection()
        if selected:  # Check if an item is selected
            sat_name = self.my_tree.item(selected, "values")[0]  # Assuming that satellite_name is in the first column
            self.delete_satellite(sat_name, selected)

    def delete_satellite(self, sat_name, selected_item):
        data = {"sat_name": sat_name}
        response = requests.post("http://127.0.0.1:8080/delete_satellite", json=data)
        result = response.json()
        print(result)

        if result.get("success"):  # If the backend confirms successful deletion
            self.remove_from_treeview(selected_item)
            messagebox.showinfo("Success", "Group deleted successfully")
        else:
            messagebox.showerror("Error", f"Failed to delete satellite: {response.text}")

    def remove_from_treeview(self, selected_item):
        for item in selected_item:  # selected_item could be a tuple of selected entries
            self.my_tree.delete(item)

    # def delete_satellite(self, primary_key, iid):
    #     print("delete function called")
    #     print(iid)

    #     data = {"name": primary_key}

    #     print("deleting satellite")
    #     response = requests.post("http://127.0.0.1:8080/delete_satellite", json=data)

    #     print(response.status_code)

    #     if response.status_code == 200:
    #         return True

    #     return False

    def go_back(self):
        self.controller.show_frame(AdminEntry)


class Groups(AdminBasePage):
    def __init__(self, parent, controller):
        super().__init__(parent, controller)
        self.controller = controller

        self.my_tree["columns"] = ("ID", "Name", "Size", "Creation date", "Course ID")

        self.my_tree.column("#0", width=120, minwidth=25)
        self.my_tree.column("ID", anchor="w", width=250, minwidth=25)
        self.my_tree.column("Name", anchor="w", width=300, minwidth=25)
        self.my_tree.column("Size", anchor="w", width=150, minwidth=25)
        self.my_tree.column("Creation date", anchor="w", width=400, minwidth=25)
        self.my_tree.column("Course ID", anchor="w", width=250, minwidth=25)

        self.my_tree.heading("#0", text="f", anchor="w")
        self.my_tree.heading("ID", text="ID", anchor="w")
        self.my_tree.heading("Name", text="Name", anchor="w")
        self.my_tree.heading("Size", text="Size", anchor="w")
        self.my_tree.heading("Creation date", text="Creation date", anchor="w")
        self.my_tree.heading("Course ID", text="Course ID", anchor="w")

        self.remove_img = tk.PhotoImage(file="trash_can.drawio.png")
        self.remove_button = tk.Button(
            self.buttons_frame,
            image=self.remove_img,
            width=70,
            height=70,
            borderwidth=0,
            highlightthickness=0,
            command=self.process_removal_request,
        )
        self.remove_button.image = self.remove_img  # Keep a reference to the image
        self.remove_button.grid(row=0, column=1, padx=20, pady=2, sticky="ns")

        self.display_groups()
        self.setup_registration_area()

    def setup_registration_area(self):
        self.group_submit_button = customtkinter.CTkButton(
            self.registration_frame,
            font=("Helvetica", 20),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            anchor="center",
            text="Create Group",
            command=self.register_group,
        )

        self.user_submit_button = customtkinter.CTkButton(
            self.registration_frame,
            font=("Helvetica", 20),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            anchor="center",
            text="Add User",
            command=self.add_user,
        )

        labels = ["Group name", "Username", "Group ID"]

        group_name_label = tk.Label(self.registration_frame, text=labels[0], bg="white")
        group_name_label.grid(row=0, column=0, sticky="w")

        self.group_name_entry = tk.Entry(self.registration_frame, borderwidth=3)
        self.group_name_entry.grid(row=0, column=1, sticky="ew", padx=0, pady=10)
        self.group_submit_button.grid(row=1, columnspan=2, pady=40)

        username_label = tk.Label(self.registration_frame, text=labels[1], bg="white")
        username_label.grid(row=2, column=0, sticky="w")
        self.username_entry = tk.Entry(self.registration_frame, borderwidth=3)
        self.username_entry.grid(row=2, column=1, sticky="ew", padx=0, pady=10)
        group_id_label = tk.Label(self.registration_frame, text=labels[2], bg="white").grid(row=3, column=0, sticky="w")
        self.group_id_entry = tk.Entry(self.registration_frame, borderwidth=3)
        self.group_id_entry.grid(row=3, column=1, sticky="ew", padx=0, pady=10)

        self.user_submit_button.grid(row=4, columnspan=2, pady=40)

    def register_group(self):
        group_name = self.group_name_entry.get().strip()  # strip to remove whitespace
        if not group_name:
            messagebox.showerror("Error", "Group name must be filled out")
            return

        data = {"group_name": group_name}
        response = requests.post("http://127.0.0.1:8080/register_group", json=data)

        if response.status_code == 200:
            messagebox.showinfo("Success", "Group created successfully")
            self.group_name_entry.delete(
                0, "end"
            )  # Clear the input field after registration
            self.display_groups()  # refresh the groups list
        else:
            messagebox.showerror("Error", f"Failed to create group: {response.text}")

    def add_user(self):
        username = self.username_entry.get().strip()
        group_id = self.group_id_entry.get().strip()

        if not username or not group_id:
            messagebox.showerror("Error", "Username and Group ID must be filled out")
            return

        data = {"username": username, "group_id": group_id}
        response = requests.post("http://127.0.0.1:8080/add_user_to_group", json=data)

        if response.status_code == 200:
            messagebox.showinfo("Success", "User added to group successfully")
            self.username_entry.delete(0, "end")  # Clear fields after adding
            self.group_id_entry.delete(0, "end")
            self.display_groups()  # Optionally refresh the groups list
        else:
            messagebox.showerror(
                "Error", f"Failed to add user to group: {response.text}"
            )

    def display_groups(self):
        for item in self.my_tree.get_children():
            self.my_tree.delete(item)

        groups = self.fetch_groups()
        print(groups)

        # Loop over courses and insert them into the treeview
        for group in groups:
            print("Inserting group:", group)  # Debugging print
            self.my_tree.insert(
                "",
                "end",
                iid=group["id"],
                values=(
                    group["id"],
                    group["name"],
                    group["size"],
                    group["creation_date"],
                    group["course_id"],
                ),
            )

            # Fetch and insert group members as child items
            members = self.fetch_group_members(group["id"])
            for member in members:
                member_iid = f"group_{group['id']}_user_{member['email']}"

                self.my_tree.insert(
                    group["id"],
                    "end",
                    iid=member_iid,
                    values=(member["email"], member["firstname"], member["lastname"]),
                )

    def fetch_groups(self):
        try:
            response = requests.get("http://127.0.0.1:8080/fetch_all_groups")
            response.raise_for_status()  # Raise HTTPError for bad response status codes
            return response.json()

        except requests.RequestException as e:
            print(f"Error fetching courses: {e}")
            return []

    def fetch_group_members(self, group_id):
        try:
            # response = requests.get(f"http://127.0.0.1:8080/fetch_group_members?group_id={group_id}")
            response = requests.get(
                f"http://127.0.0.1:8080/fetch_group_members/{group_id}"
            )

            response.raise_for_status()  # Raise HTTPError for bad response status codes
            return response.json()

        except requests.RequestException as e:
            print(f"Error fetching groups: {e}")
            return []

    def process_removal_request(self):
        selected = self.my_tree.selection()
        if selected:  # Check if an item is selected
            group_id = self.my_tree.item(selected, "values")[0]  # Assuming the group_id is in the first column
            self.delete_group(group_id, selected)

    def delete_group(self, group_id, selected_item):
        data = {"id": group_id}
        response = requests.post("http://127.0.0.1:8080/delete_group", json=data)
        result = response.json()
        print(result)

        if result.get("success"):  # If the backend confirms successful deletion
            self.remove_from_treeview(selected_item)
            messagebox.showinfo("Success", "Group deleted successfully")
        else:
            messagebox.showerror("Error", f"Failed to delete group: {response.text}")

    def remove_from_treeview(self, selected_item):
        for item in selected_item:  # selected_item could be a tuple of selected entries
            self.my_tree.delete(item)

    def go_back(self):
        print("Go back button has been pressed")
        self.controller.show_frame(AdminEntry)


class Courses(AdminBasePage):
    def __init__(self, parent, controller):
        super().__init__(parent, controller)
        self.controller = controller

        # Adjust grid row configuration
        self.grid_rowconfigure(1, weight=1)  # Treeview
        self.grid_rowconfigure(2, weight=0)  # Buttons should not expand much

        self.add_img = tk.PhotoImage(file="add_symbol.drawio.png")
        self.remove_img = tk.PhotoImage(file="remove_symbol.drawio.png")

        # Frame for the treeview
        treeview_frame = tk.Frame(self, bg="white")
        treeview_frame.grid(row=1, column=0, sticky="nsew")

        # Configure the grid for the buttons frame
        treeview_frame.grid_columnconfigure(0, weight=1)
        treeview_frame.grid_columnconfigure(1, weight=1)

        # Frame for the buttons
        buttons_frame = tk.Frame(self, bg="white")
        buttons_frame.grid(row=2, column=0, sticky="nsew")

        # The buttons
        self.add_button = tk.Button(
            buttons_frame,
            width=50,
            height=50,
            image=self.add_img,
            borderwidth=0,
            highlightthickness=0,
            # command=self.create_popup,
        )
        self.add_button.image = self.add_img  # Keep a reference to the image
        self.add_button.grid(row=0, column=0, padx=20, pady=2, sticky="ns")

        self.remove_button = tk.Button(
            buttons_frame,
            image=self.remove_img,
            width=50,
            height=50,
            borderwidth=0,
            highlightthickness=0,
            # command=self.process_removal_request,
        )
        self.remove_button.image = self.remove_img  # Keep a reference to the image
        self.remove_button.grid(row=0, column=1, padx=20, pady=2, sticky="ns")

        # Create a frame for the calender widgets
        calendar_frame = tk.Frame(self, bg="white")
        calendar_frame.grid(row=1, column=1, sticky="nsew")
        today = date.today()

        self.cal_start = Calendar(
            calendar_frame,
            selectmode="day",
            year=today.year,
            month=today.month,
            day=today.day,
        )
        self.cal_start.grid(row=0, column=6, pady=20)

        self.cal_end = Calendar(
            calendar_frame,
            selectmode="day",
            year=today.year,
            month=today.month,
            day=today.day,
        )
        self.cal_end.grid(row=1, column=6, pady=20)

        # Add Button and Label
        self.submit_button = customtkinter.CTkButton(
            calendar_frame, text="Confirm", command=self.submit_dates
        )
        self.submit_button.grid(row=2, column=6, pady=20)

        style = ttk.Style(self.master)
        style.theme_use("clam")
        style.configure(
            "Treeview",
            background="gray25",
            foreground="white",
            rowheight=45,
            fieldbackground="gray 25",
        )
        style.map("Treeview", background=[("selected", "orange")])

        self.my_tree = ttk.Treeview(
            treeview_frame,
            height=30,
        )

        self.my_tree["columns"] = ("ID", "Start date", "End date")

        self.display_courses()

        self.my_tree.column("#0", width=0)
        self.my_tree.column("ID", anchor="w", width=300, minwidth=25)
        self.my_tree.column("Start date", anchor="w", width=300, minwidth=25)
        self.my_tree.column("End date", anchor="w", width=300, minwidth=25)

        self.my_tree.heading("#0", text="f", anchor="w")
        self.my_tree.heading("ID", text="ID/Course No.", anchor="w")
        self.my_tree.heading("Start date", text="Start date", anchor="w")
        self.my_tree.heading("End date", text="End date", anchor="w")

        self.my_tree.grid(row=0, column=0, padx=20, pady=20)

    def display_courses(self):
        # Fetch and clear existing items
        for item in self.my_tree.get_children():
            self.my_tree.delete(item)

        # Fetch courses from the backend
        courses = self.fetch_courses()

        # Loop over courses and insert them into the treeview
        for course in courses:
            course_id = course["id"]
            course_item = self.my_tree.insert(
                "",
                "end",
                iid=course_id,
                values=(course_id, course["start_date"], course["end_date"]),
            )

            print("course_id", course_id)
            # Fetch groups for the given course_id
            groups = self.fetch_attached_groups(course_id)

            print("Groups fetched:", groups)
            # Loop over the groups and insert them as children of the course
            for group in groups:
                print(
                    type(group), group
                )  # This will help determine what `group` actually is

                group_id = group["id"]
                group_iid = f"{course_id}-{group_id}"  # Corrected to create a unique composite identifier¨
                self.my_tree.insert(
                    course_item,
                    "end",
                    iid=group_iid,
                    values=(group["id"], group["name"], group["size"]),
                )

    def fetch_courses(self):
        try:
            response = requests.get("http://127.0.0.1:8080/fetch_courses")
            response.raise_for_status()  # Raise HTTPError for bad response status codes
            return response.json()

        except requests.RequestException as e:
            print(f"Error fetching courses: {e}")
            return []

    def fetch_attached_groups(self, course_id):
        try:
            response = requests.get(
                f"http://127.0.0.1:8080/fetch_attached_groups/{course_id}"
            )
            response.raise_for_status()  # Raise HTTPError for bad response status codes
            return response.json()

        except requests.RequestException as e:
            print(f"Error fetching groups: {e}")
            return []

    def detach_group_from_course(self):
        # self.my_tree.delete(tk.ANCHOR) does not work for some reason
        selected_item = self.my_tree.selection()
        if selected_item:  # Check if an item is selected
            self.my_tree.delete(selected_item)

    def submit_dates(self):
        # Fetch the selected dates from the calendar
        start_date_str = self.cal_start.get_date()
        end_date_str = self.cal_end.get_date()

        # Convert dates from M/D/YY to YYYY-MM-DD
        start_date_obj = datetime.strptime(start_date_str, "%m/%d/%y")
        end_date_obj = datetime.strptime(end_date_str, "%m/%d/%y")
        start_date = start_date_obj.strftime("%Y-%m-%d")
        end_date = end_date_obj.strftime("%Y-%m-%d")

        # Make sure end date is not before start date
        if end_date_obj < start_date_obj:
            print("ERROR: End date cannot be before start date!")
            return

        data = {"start": start_date, "end": end_date}

        response = requests.post(
            "http://127.0.0.1:8080/register_course", json=data
        )  # contacts backend server
        result = response.json()
        print(result)

    def go_back(self):
        self.controller.show_frame(AdminEntry)


class Users(AdminBasePage):
    def __init__(self, parent, controller):
        super().__init__(parent, controller)
        self.controller = controller

        self.remove_img = tk.PhotoImage(file="trash_can.drawio.png")
        self.remove_button = tk.Button(
            self.buttons_frame,
            image=self.remove_img,
            width=70,
            height=70,
            borderwidth=0,
            highlightthickness=0,
            command=self.process_removal_request,
        )

        self.remove_button.image = self.remove_img  # Keep a reference to the image
        self.remove_button.pack(side="left", padx=20, pady=5)

        self.my_tree["columns"] = (
            "ID/email",
            "Firstname",
            "Lastname",
            "User Type",
        )

        self.my_tree.column("#0", width=0)
        self.my_tree.column("ID/email", anchor="w", width=500, minwidth=25)
        self.my_tree.column("Firstname", anchor="w", width=350, minwidth=25)
        self.my_tree.column("Lastname", anchor="w", width=350, minwidth=25)
        self.my_tree.column("User Type", anchor="w", width=120, minwidth=25)

        self.my_tree.heading("#0", text="", anchor="w")
        self.my_tree.heading("ID/email", text="ID", anchor="w")
        self.my_tree.heading("Firstname", text="Firstname", anchor="w")
        self.my_tree.heading("Lastname", text="Lastname", anchor="w")
        self.my_tree.heading("User Type", text="User Type", anchor="w")

        self.my_tree.grid(row=0, column=0, pady=20)

        self.display_users()
        self.setup_registration_area()

    def display_users(self):
        for item in self.my_tree.get_children():
            self.my_tree.delete(item)

        users = self.fetch_users()

        print(users)

        # Loop over courses and insert them into the treeview
        for user in users:
            print("Inserting user:", user)  # Debugging print
            self.my_tree.insert(
                "",
                "end",
                iid=user["email"],
                values=(
                    user["email"],
                    user["firstname"],
                    user["lastname"],
                    user["user_type"],
                ),
            )

    def fetch_users(self):
        try:
            response = requests.get("http://127.0.0.1:8080/fetch_all_users")
            response.raise_for_status()  # Raise HTTPError for bad response status codes
            return response.json()

        except requests.RequestException as e:
            print(f"Error fetching courses: {e}")
            return []

    def setup_registration_area(self):
        labels = ["Email", "User Type"]

        self.entries = {}
        for i, label in enumerate(labels):
            # Placing labels and entry widgets in vertical order
            tk.Label(self.registration_frame, text=label, bg="white").grid(
                row=i, column=0, sticky="w"
            )

            if label == "User Type":
                user_types = ["Student", "Admin"]  # Example user types
                self.clicked = tk.StringVar(value=user_types[0])
                entry = tk.OptionMenu(self.registration_frame, self.clicked, *user_types)
            else:
                entry = tk.Entry(self.registration_frame, borderwidth=3)

            entry.grid(row=i, column=1, sticky="ew", padx=0, pady=10)
            self.entries[label] = entry  # Storing the entries in a dictionary

        # submit_button = tk.Button(
        #     self.registration_frame,
        #     text="Submit",
        #     command=self.process_entries
        # )
        # submit_button.grid(row=len(labels), column=0, columnspan=2, pady=10)

        submit_button = customtkinter.CTkButton(
            self.registration_frame,
            font=("Helvetica", 20),
            fg_color="orange",
            text_color="black",
            corner_radius=8,
            border_width=3,
            border_color="black",
            hover_color="DarkOrange2",
            anchor="center",
            text="Change user type",
            command=self.process_change_request
        )
        submit_button.grid(row=len(labels), column=0, columnspan=2, pady=40)

    def process_change_request(self):
        data = {
            "email": self.entries["Email"].get(),
            "user_type": self.clicked.get(),
        }
        self.change_user_type(data)

    def change_user_type(self, data):
        response = requests.post(
            "http://127.0.0.1:8080/change_user_type", json=data
        )  # contacts backend server
        result = response.json()
        print(result)

        if response.status_code == 200:
            # self.update_treeview(data)
            self.display_users()

    def process_removal_request(self):
        selected = self.my_tree.selection()
        if selected:  # Check if an item is selected
            email = self.my_tree.item(selected, "values")[0]  # Assuming the email is in the first column
            self.delete_user(email, selected)

    def delete_user(self, email, selected_item):
        data = {"email": email}
        response = requests.post("http://127.0.0.1:8080/delete_user", json=data)
        result = response.json()
        print(result)

        if result.get("success"):  # If the backend confirms successful deletion
            self.remove_from_treeview(selected_item)

    def remove_from_treeview(self, selected_item):
        for item in selected_item:  # selected_item could be a tuple of selected entries
            self.my_tree.delete(item)

    # def update_treeview(self, data):
    #     self.my_tree.update(
    #         "",
    #         "end",
    #         iid=data["email"],
    #         values=(
    #             data["user_type"],
    #         ),
    #     )

    def go_back(self):
        self.controller.show_frame(AdminEntry)

def run_flask():
    app = create_app()
    app.run(host='0.0.0.0', port=8080)


def flask_process_shutdown(pid):
    main_module = importlib.import_module("__main__")
    sample_app = getattr(main_module, "app", None)

    if sample_app is not None and PlotInterface in sample_app.frames:
        sample_app.frames[PlotInterface].on_closing()

    os.kill(pid, signal.SIGINT)  # or signal.SIGTERM

def run_tkinter():
    global app
    app = SampleApp()
    pid = os.getpid()
    app.protocol("WM_DELETE_WINDOW", lambda: (flask_process_shutdown(pid), app.quit()))  # override closing
    width = app.winfo_screenwidth()
    height = app.winfo_screenheight()
    app.geometry(f"{width}x{height}+0+0")
    app.mainloop()

if __name__ == "__main__":
    flask_thread = Process(target=run_flask)
    tkinter_thread = threading.Thread(target=run_tkinter)

    flask_thread.start()
    tkinter_thread.start()

